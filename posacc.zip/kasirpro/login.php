<?php
require __DIR__ . '/config.php';
$pdo = db();
$first = (int)$pdo->query('SELECT COUNT(*) FROM users')->fetchColumn() === 0;
$err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $un = trim($_POST['username'] ?? '');
    $pw = $_POST['password'] ?? '';
    if ($first) {
        $nama = trim($_POST['nama'] ?? '');
        if ($un === '' || $nama === '' || strlen($pw) < 8) {
            $err = 'Isi semua kolom. Kata sandi minimal 8 karakter.';
        } else {
            $pdo->prepare('INSERT INTO users (username,nama,password_hash,role) VALUES (?,?,?,"manager")')
                ->execute([$un, $nama, password_hash($pw, PASSWORD_DEFAULT)]);
        }
    }
    if (!$err) {
        $st = $pdo->prepare('SELECT * FROM users WHERE username=? AND aktif=1');
        $st->execute([$un]);
        $row = $st->fetch();
        if ($row && password_verify($pw, $row['password_hash'])) {
            session_regenerate_id(true);
            $_SESSION['user'] = ['id' => $row['id'], 'username' => $row['username'], 'nama' => $row['nama'], 'role' => $row['role']];
            header('Location: index.php'); exit;
        }
        $err = 'Nama pengguna atau kata sandi salah.';
    }
}
if (user()) { header('Location: index.php'); exit; }
?><!doctype html>
<html lang="id"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Masuk - <?= APP_NAME ?></title><link rel="stylesheet" href="assets/style.css"></head>
<body class="login">
<form method="post" class="box">
  <h1><?= APP_NAME ?></h1>
  <p class="muted"><?= $first ? 'Belum ada pengguna. Buat akun Manager pertama.' : 'Masuk untuk melanjutkan.' ?></p>
  <?php if ($err): ?><div class="flash err"><?= e($err) ?></div><?php endif; ?>
  <input type="hidden" name="csrf" value="<?= e(csrf()) ?>">
  <?php if ($first): ?>
    <label>Nama lengkap<input name="nama" required></label>
  <?php endif; ?>
  <label>Nama pengguna<input name="username" autocomplete="username" required autofocus></label>
  <label>Kata sandi<input type="password" name="password" autocomplete="current-password" required></label>
  <button class="btn"><?= $first ? 'Buat akun dan masuk' : 'Masuk' ?></button>
</form>
</body></html>
