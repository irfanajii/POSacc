USE pos_accurate;

-- PPN pada transaksi
ALTER TABLE transaksi
  ADD COLUMN subtotal DECIMAL(15,2) NOT NULL DEFAULT 0 AFTER gudang_id,
  ADD COLUMN ppn_persen DECIMAL(5,2) NOT NULL DEFAULT 0 AFTER subtotal,
  ADD COLUMN ppn DECIMAL(15,2) NOT NULL DEFAULT 0 AFTER ppn_persen;
UPDATE transaksi SET subtotal = total;
ALTER TABLE pembayaran ADD COLUMN ket VARCHAR(80) NULL;

-- Harga bertingkat
ALTER TABLE barang
  ADD COLUMN harga_jual2 DECIMAL(15,2) NOT NULL DEFAULT 0 AFTER harga_jual,
  ADD COLUMN harga_jual3 DECIMAL(15,2) NOT NULL DEFAULT 0 AFTER harga_jual2;
ALTER TABLE pelanggan ADD COLUMN level_harga TINYINT NOT NULL DEFAULT 1;

-- Retur
CREATE TABLE retur (
  id INT AUTO_INCREMENT PRIMARY KEY,
  tipe ENUM('jual','beli') NOT NULL,
  nomor VARCHAR(30) NOT NULL UNIQUE,
  tanggal DATE NOT NULL,
  transaksi_id INT NOT NULL, gudang_id INT NOT NULL,
  subtotal DECIMAL(15,2) NOT NULL, ppn DECIMAL(15,2) NOT NULL DEFAULT 0, total DECIMAL(15,2) NOT NULL,
  potong DECIMAL(15,2) NOT NULL DEFAULT 0, refund DECIMAL(15,2) NOT NULL DEFAULT 0,
  catatan VARCHAR(255) NULL, user_id INT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX (tipe, tanggal),
  FOREIGN KEY (transaksi_id) REFERENCES transaksi(id),
  FOREIGN KEY (gudang_id) REFERENCES gudang(id),
  FOREIGN KEY (user_id) REFERENCES users(id)
);
CREATE TABLE retur_item (
  id INT AUTO_INCREMENT PRIMARY KEY,
  retur_id INT NOT NULL, barang_id INT NOT NULL,
  qty DECIMAL(15,2) NOT NULL, harga DECIMAL(15,2) NOT NULL, subtotal DECIMAL(15,2) NOT NULL,
  FOREIGN KEY (retur_id) REFERENCES retur(id) ON DELETE CASCADE,
  FOREIGN KEY (barang_id) REFERENCES barang(id)
);

-- Akun tambahan
INSERT IGNORE INTO akun (kode, nama, tipe) VALUES
 ('1-1400','PPN Masukan','Aset'),
 ('2-1100','PPN Keluaran','Kewajiban'),
 ('3-1100','Modal Saldo Awal','Modal'),
 ('5-1100','Selisih Persediaan','Beban');

INSERT IGNORE INTO pengaturan (k, v) VALUES ('ppn_aktif','0'), ('ppn_persen','11');
