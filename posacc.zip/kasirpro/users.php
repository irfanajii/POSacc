<?php
require __DIR__ . '/config.php';
require __DIR__ . '/includes/layout.php';
require_role(['manager']);
$pdo = db(); $me = user()['id'];
$roles = ['manager' => 'Manager', 'supervisor' => 'Supervisor', 'kasir' => 'Admin/Kasir'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $act = $_POST['action'] ?? ''; $id = (int)($_POST['id'] ?? 0);
    try {
        if ($act === 'add') {
            $un = trim($_POST['username'] ?? ''); $nama = trim($_POST['nama'] ?? '');
            $pw = $_POST['password'] ?? ''; $rl = $_POST['role'] ?? '';
            if ($un === '' || $nama === '' || strlen($pw) < 8 || !isset($roles[$rl])) flash('Isi semua kolom. Kata sandi minimal 8 karakter.', 'err');
            else {
                $pdo->prepare('INSERT INTO users (username,nama,password_hash,role) VALUES (?,?,?,?)')
                    ->execute([$un, $nama, password_hash($pw, PASSWORD_DEFAULT), $rl]);
                flash('Pengguna ditambahkan.');
            }
        } elseif ($act === 'toggle' && $id !== $me) {
            $pdo->prepare('UPDATE users SET aktif = 1 - aktif WHERE id=?')->execute([$id]);
            flash('Status pengguna diubah.');
        } elseif ($act === 'reset') {
            $pw = $_POST['password'] ?? '';
            if (strlen($pw) < 8) flash('Kata sandi minimal 8 karakter.', 'err');
            else { $pdo->prepare('UPDATE users SET password_hash=? WHERE id=?')->execute([password_hash($pw, PASSWORD_DEFAULT), $id]); flash('Kata sandi diganti.'); }
        } elseif ($act === 'role' && $id !== $me && isset($roles[$_POST['role'] ?? ''])) {
            $pdo->prepare('UPDATE users SET role=? WHERE id=?')->execute([$_POST['role'], $id]);
            flash('Level akses diubah.');
        }
    } catch (PDOException $ex) { flash('Nama pengguna sudah dipakai.', 'err'); }
    header('Location: users.php'); exit;
}
$users = $pdo->query('SELECT * FROM users ORDER BY id')->fetchAll();
page_start('Pengguna', 'users');
?>
<div class="panel">
  <h2>Tambah pengguna</h2>
  <form method="post" class="grid">
    <input type="hidden" name="csrf" value="<?= e(csrf()) ?>"><input type="hidden" name="action" value="add">
    <label>Nama lengkap<input name="nama" required></label>
    <label>Nama pengguna<input name="username" required></label>
    <label>Kata sandi<input type="password" name="password" minlength="8" required></label>
    <label>Level akses<select name="role"><?php foreach ($roles as $k => $v) echo "<option value=\"$k\">$v</option>"; ?></select></label>
    <div class="actions"><button class="btn">Tambah</button></div>
  </form>
</div>
<div class="panel"><div class="scroll"><table>
  <thead><tr><th>Nama</th><th>Pengguna</th><th>Level</th><th>Status</th><th>Kata sandi baru</th><th></th></tr></thead>
  <?php foreach ($users as $u): ?>
  <tr>
    <td><?= e($u['nama']) ?></td><td><?= e($u['username']) ?></td>
    <td>
      <form method="post" class="inline"><input type="hidden" name="csrf" value="<?= e(csrf()) ?>">
        <input type="hidden" name="action" value="role"><input type="hidden" name="id" value="<?= $u['id'] ?>">
        <select name="role" onchange="this.form.submit()" <?= $u['id'] == $me ? 'disabled' : '' ?>>
          <?php foreach ($roles as $k => $v): ?><option value="<?= $k ?>" <?= $u['role'] === $k ? 'selected' : '' ?>><?= $v ?></option><?php endforeach; ?>
        </select></form>
    </td>
    <td><?= $u['aktif'] ? 'Aktif' : 'Nonaktif' ?></td>
    <td>
      <form method="post" class="inline"><input type="hidden" name="csrf" value="<?= e(csrf()) ?>">
        <input type="hidden" name="action" value="reset"><input type="hidden" name="id" value="<?= $u['id'] ?>">
        <input type="password" name="password" minlength="8" placeholder="min. 8 karakter" required>
        <button class="btn ghost">Ganti</button></form>
    </td>
    <td class="act"><?php if ($u['id'] != $me): ?>
      <form method="post"><input type="hidden" name="csrf" value="<?= e(csrf()) ?>">
        <input type="hidden" name="action" value="toggle"><input type="hidden" name="id" value="<?= $u['id'] ?>">
        <button class="link"><?= $u['aktif'] ? 'Nonaktifkan' : 'Aktifkan' ?></button></form><?php endif; ?></td>
  </tr>
  <?php endforeach; ?>
</table></div></div>
<?php page_end();
