<?php
require __DIR__ . '/config.php';
require __DIR__ . '/includes/layout.php';
require_login();

$key = $_GET['e'] ?? '';
if (!isset($ENT[$key])) { http_response_code(404); exit('Data tidak ditemukan.'); }
$cfg = $ENT[$key]; $t = $cfg['table']; $pdo = db(); $role = user()['role'];
$canEdit = in_array($role, ['manager', 'supervisor'], true) || in_array($key, ['pelanggan'], true);
$canDelete = $role === 'manager';
$row = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $act = $_POST['action'] ?? '';
    try {
        if ($act === 'delete') {
            if (!$canDelete) { http_response_code(403); exit('Hanya Manager yang boleh menghapus.'); }
            $pdo->prepare("DELETE FROM `$t` WHERE id=?")->execute([(int)$_POST['id']]);
            flash('Data dihapus.');
            header('Location: master.php?e=' . $key); exit;
        }
        if ($act === 'save') {
            if (!$canEdit) { http_response_code(403); exit('Anda tidak boleh mengubah data ini.'); }
            $vals = []; $err = '';
            foreach ($cfg['fields'] as $f => $d) {
                $v = trim($_POST[$f] ?? '');
                if (!empty($d['req']) && $v === '') { $err = $d[0] . ' wajib diisi.'; break; }
                if ($d[1] === 'number') $v = $v === '' ? 0 : (float)$v;
                elseif ($d[1] === 'select') $v = $v === '' ? null : (int)$v;
                elseif ($d[1] === 'enum' && !in_array($v, $d['opts'], true)) { $err = $d[0] . ' tidak valid.'; break; }
                elseif ($v === '') $v = null;
                $vals[$f] = $v;
            }
            if ($err) { flash($err, 'err'); $row = $_POST; }
            else {
                $id = (int)($_POST['id'] ?? 0);
                if ($id) {
                    $set = implode(',', array_map(fn($f) => "`$f`=?", array_keys($vals)));
                    $pdo->prepare("UPDATE `$t` SET $set WHERE id=?")->execute(array_merge(array_values($vals), [$id]));
                } else {
                    $cols = implode(',', array_map(fn($f) => "`$f`", array_keys($vals)));
                    $ph = implode(',', array_fill(0, count($vals), '?'));
                    $pdo->prepare("INSERT INTO `$t` ($cols) VALUES ($ph)")->execute(array_values($vals));
                }
                flash('Data tersimpan.');
                header('Location: master.php?e=' . $key); exit;
            }
        }
    } catch (PDOException $ex) {
        flash($ex->getCode() === '23000'
            ? ($act === 'delete' ? 'Data sedang dipakai dan tidak bisa dihapus.' : 'Kode atau nama sudah dipakai.')
            : 'Terjadi kesalahan database.', 'err');
        if ($act === 'save') $row = $_POST;
    }
}

if (!$row && isset($_GET['edit'])) {
    $st = $pdo->prepare("SELECT * FROM `$t` WHERE id=?");
    $st->execute([(int)$_GET['edit']]);
    $row = $st->fetch() ?: [];
}

// opsi untuk field select
$lookup = [];
foreach ($cfg['fields'] as $f => $d)
    if ($d[1] === 'select') $lookup[$f] = $pdo->query("SELECT id,nama FROM `{$d['src']}` ORDER BY nama")->fetchAll(PDO::FETCH_KEY_PAIR);

$q = trim($_GET['q'] ?? '');
$hasKode = isset($cfg['fields']['kode']);
$where = $q === '' ? '' : ($hasKode ? 'WHERE nama LIKE ? OR kode LIKE ?' : 'WHERE nama LIKE ?');
$st = $pdo->prepare("SELECT * FROM `$t` $where ORDER BY id DESC LIMIT 200");
$st->execute($q === '' ? [] : ($hasKode ? ["%$q%", "%$q%"] : ["%$q%"]));
$data = $st->fetchAll();

page_start($cfg['title'], $key);
if ($canEdit): ?>
<div class="panel">
  <h2><?= !empty($row['id']) ? 'Ubah data' : 'Tambah data' ?></h2>
  <form method="post" class="grid">
    <input type="hidden" name="csrf" value="<?= e(csrf()) ?>">
    <input type="hidden" name="action" value="save">
    <input type="hidden" name="id" value="<?= e($row['id'] ?? '') ?>">
    <?php foreach ($cfg['fields'] as $f => $d): $val = $row[$f] ?? ''; ?>
      <label><?= e($d[0]) ?><?= !empty($d['req']) ? ' *' : '' ?>
      <?php if ($d[1] === 'textarea'): ?>
        <textarea name="<?= $f ?>" rows="2"><?= e($val) ?></textarea>
      <?php elseif ($d[1] === 'select'): ?>
        <select name="<?= $f ?>"><option value="">-</option>
          <?php foreach ($lookup[$f] as $id => $nm): ?>
            <option value="<?= $id ?>" <?= (string)$val === (string)$id ? 'selected' : '' ?>><?= e($nm) ?></option>
          <?php endforeach; ?></select>
      <?php elseif ($d[1] === 'enum'): ?>
        <select name="<?= $f ?>"><?php foreach ($d['opts'] as $o): ?>
          <option <?= (string)$val === (string)$o ? 'selected' : '' ?>><?= e($o) ?></option><?php endforeach; ?></select>
      <?php else: ?>
        <input name="<?= $f ?>" type="<?= $d[1] === 'number' ? 'number' : e($d[1]) ?>" <?= $d[1] === 'number' ? 'step="any" min="0"' : '' ?>
               value="<?= e($val) ?>" <?= !empty($d['req']) ? 'required' : '' ?>>
      <?php endif; ?></label>
    <?php endforeach; ?>
    <div class="actions">
      <button class="btn">Simpan</button>
      <?php if (!empty($row['id'])): ?><a class="btn ghost" href="master.php?e=<?= $key ?>">Batal</a><?php endif; ?>
    </div>
  </form>
</div>
<?php endif; ?>

<div class="panel">
  <form method="get" class="search">
    <input type="hidden" name="e" value="<?= $key ?>">
    <input name="q" value="<?= e($q) ?>" placeholder="Cari nama<?= $hasKode ? ' atau kode' : '' ?>">
    <button class="btn ghost">Cari</button>
  </form>
  <div class="scroll"><table>
    <thead><tr>
      <?php foreach ($cfg['list'] as $f): ?><th><?= e($cfg['fields'][$f][0]) ?></th><?php endforeach; ?>
      <th></th>
    </tr></thead>
    <tbody>
    <?php foreach ($data as $r): ?>
      <tr>
        <?php foreach ($cfg['list'] as $f): $d = $cfg['fields'][$f]; ?>
          <?php if ($d[1] === 'number'): ?><td class="num"><?= rp($r[$f]) ?></td>
          <?php elseif ($d[1] === 'select'): ?><td><?= e($lookup[$f][$r[$f]] ?? '-') ?></td>
          <?php else: ?><td><?= e($r[$f]) ?></td><?php endif; ?>
        <?php endforeach; ?>
        <td class="act">
          <?php if ($canEdit): ?><a href="master.php?e=<?= $key ?>&edit=<?= $r['id'] ?>">Ubah</a><?php endif; ?>
          <?php if ($canDelete): ?>
          <form method="post" onsubmit="return confirm('Hapus data ini?')">
            <input type="hidden" name="csrf" value="<?= e(csrf()) ?>">
            <input type="hidden" name="action" value="delete">
            <input type="hidden" name="id" value="<?= $r['id'] ?>">
            <button class="link danger">Hapus</button>
          </form><?php endif; ?>
        </td>
      </tr>
    <?php endforeach; ?>
    <?php if (!$data): ?><tr><td colspan="<?= count($cfg['list']) + 1 ?>" class="muted">Belum ada data.</td></tr><?php endif; ?>
    </tbody>
  </table></div>
</div>
<?php page_end();
