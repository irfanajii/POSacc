<?php
require_once __DIR__ . '/entities.php';
require_once __DIR__ . '/lib.php';

function page_start(string $title, string $active = ''): void {
    global $ENT;
    $u = user(); $r = $u['role'];
    $ms = in_array($r, ['manager', 'supervisor'], true);
    $link = function (string $href, string $label, string $key) use ($active) {
        return '<a' . ($key === $active ? ' class="on"' : '') . ' href="' . e($href) . '">' . e($label) . '</a>';
    };
    ?><!doctype html>
<html lang="id"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($title) ?> - <?= APP_NAME ?></title>
<link rel="stylesheet" href="assets/style.css">
</head><body>
<div class="app">
  <nav class="side no-print">
    <div class="brand"><?= APP_NAME ?></div>
    <?= $link('index.php', 'Dashboard', 'dashboard') ?>
    <div class="grp">Transaksi</div>
    <?= $link('transaksi.php?t=jual', 'Penjualan', 'jual') ?>
    <?php if ($ms) { echo $link('transaksi.php?t=beli', 'Pembelian', 'beli'); echo $link('retur.php?t=jual', 'Retur penjualan', 'rjual'); echo $link('retur.php?t=beli', 'Retur pembelian', 'rbeli'); } ?>
    <?= $link('stok.php', 'Stok barang', 'stok') ?>
    <?php if ($ms): ?>
      <div class="grp">Akuntansi</div>
      <?= $link('jurnal.php', 'Jurnal umum', 'jurnal') ?>
      <?= $link('laporan.php?j=penjualan', 'Laporan', 'laporan') ?>
    <?php endif; ?>
    <div class="grp">Data master</div>
    <?php foreach ($ENT as $k => $c) echo $link('master.php?e=' . $k, $c['title'], $k); ?>
    <?php if ($ms || $r === 'manager'): ?>
      <div class="grp">Pengaturan</div>
      <?= $link('nota_setting.php', 'Desain nota', 'nota_setting') ?>
      <?php if ($r === 'manager') { echo $link('pajak.php', 'Pajak (PPN)', 'pajak'); echo $link('saldo_awal.php', 'Saldo awal', 'saldo'); echo $link('users.php', 'Pengguna', 'users'); } ?>
    <?php endif; ?>
  </nav>
  <div class="main">
    <header class="top no-print">
      <h1><?= e($title) ?></h1>
      <div class="who"><?= e($u['nama']) ?> (<?= e($r) ?>) &nbsp;<a href="logout.php">Keluar</a></div>
    </header>
    <main>
    <?php if ($f = flash()): ?><div class="flash <?= e($f[1]) ?> no-print"><?= e($f[0]) ?></div><?php endif; ?>
<?php
}
function page_end(): void { echo "</main></div></div></body></html>"; }
