<?php
function setting(string $k, string $d = ''): string {
    static $c = null;
    if ($c === null) $c = db()->query('SELECT k,v FROM pengaturan')->fetchAll(PDO::FETCH_KEY_PAIR);
    return (string)($c[$k] ?? $d);
}
function set_setting(string $k, string $v): void {
    db()->prepare('INSERT INTO pengaturan (k,v) VALUES (?,?) ON DUPLICATE KEY UPDATE v=VALUES(v)')->execute([$k, $v]);
}
function qf($n): string { return rtrim(rtrim(number_format((float)$n, 2, ',', '.'), '0'), ','); }
function tgl($d): string { return $d ? date('d/m/Y', strtotime($d)) : '-'; }
function bulan_param(): string {
    $b = $_GET['bulan'] ?? date('Y-m');
    return preg_match('/^\d{4}-(0[1-9]|1[0-2])$/', $b) ? $b : date('Y-m');
}
function akun_id(string $kode): int {
    $s = db()->prepare('SELECT id FROM akun WHERE kode=?');
    $s->execute([$kode]);
    $id = $s->fetchColumn();
    if (!$id) throw new RuntimeException("Akun $kode tidak ditemukan");
    return (int)$id;
}
function nomor(string $prefix, string $tanggal, string $tabel = 'transaksi'): string {
    $tabel = $tabel === 'retur' ? 'retur' : 'transaksi';
    $ym = date('ym', strtotime($tanggal));
    $s = db()->prepare("SELECT COUNT(*) FROM `$tabel` WHERE nomor LIKE ?");
    $s->execute(["$prefix-$ym-%"]);
    return sprintf('%s-%s-%04d', $prefix, $ym, $s->fetchColumn() + 1);
}
function stok(int $barang, ?int $gudang = null): float {
    $sql = 'SELECT COALESCE(SUM(qty),0) FROM stok_log WHERE barang_id=?'; $p = [$barang];
    if ($gudang) { $sql .= ' AND gudang_id=?'; $p[] = $gudang; }
    $s = db()->prepare($sql); $s->execute($p);
    return (float)$s->fetchColumn();
}
// $lines: [[kode_akun, debit, kredit], ...]
function post_jurnal(string $tgl, string $ket, string $refTipe, int $refId, array $lines): void {
    $pdo = db();
    if (abs(array_sum(array_column($lines, 1)) - array_sum(array_column($lines, 2))) > 0.005)
        throw new RuntimeException('Jurnal tidak seimbang');
    $pdo->prepare('INSERT INTO jurnal (tanggal,ket,ref_tipe,ref_id) VALUES (?,?,?,?)')->execute([$tgl, $ket, $refTipe, $refId]);
    $jid = (int)$pdo->lastInsertId();
    $st = $pdo->prepare('INSERT INTO jurnal_detail (jurnal_id,akun_id,debit,kredit) VALUES (?,?,?,?)');
    foreach ($lines as [$kode, $d, $k]) if ($d > 0 || $k > 0) $st->execute([$jid, akun_id($kode), $d, $k]);
}
