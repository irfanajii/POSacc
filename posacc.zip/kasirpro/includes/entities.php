<?php
// Definisi data master. Tambah entitas baru cukup dengan menambah array di sini.
// Tipe field: text, email, textarea, number, select (id dari tabel 'src'), enum ('opts').
$ENT = [
  'pelanggan' => ['title' => 'Pelanggan', 'table' => 'pelanggan',
    'fields' => [
      'kode' => ['Kode', 'text', 'req' => true], 'nama' => ['Nama', 'text', 'req' => true],
      'telepon' => ['Telepon', 'text'], 'email' => ['Email', 'email'],
      'alamat' => ['Alamat', 'textarea'], 'limit_piutang' => ['Limit piutang', 'number'],
      'level_harga' => ['Level harga (1 eceran, 2 grosir, 3 partai)', 'enum', 'opts' => ['1', '2', '3']],
    ],
    'list' => ['kode', 'nama', 'telepon', 'limit_piutang']],
  'pemasok' => ['title' => 'Pemasok', 'table' => 'pemasok',
    'fields' => [
      'kode' => ['Kode', 'text', 'req' => true], 'nama' => ['Nama', 'text', 'req' => true],
      'telepon' => ['Telepon', 'text'], 'email' => ['Email', 'email'], 'alamat' => ['Alamat', 'textarea'],
    ],
    'list' => ['kode', 'nama', 'telepon', 'email']],
  'barang' => ['title' => 'Barang & jasa', 'table' => 'barang',
    'fields' => [
      'kode' => ['Kode', 'text', 'req' => true], 'nama' => ['Nama barang', 'text', 'req' => true],
      'kategori_id' => ['Kategori', 'select', 'src' => 'kategori'],
      'satuan_id' => ['Satuan', 'select', 'src' => 'satuan'],
      'harga_beli' => ['Harga beli', 'number'], 'harga_jual' => ['Harga jual (eceran)', 'number'],
      'harga_jual2' => ['Harga jual grosir', 'number'], 'harga_jual3' => ['Harga jual partai', 'number'],
      'stok_minimum' => ['Stok minimum', 'number'],
    ],
    'list' => ['kode', 'nama', 'kategori_id', 'satuan_id', 'harga_beli', 'harga_jual']],
  'kategori' => ['title' => 'Kategori barang', 'table' => 'kategori',
    'fields' => ['nama' => ['Nama kategori', 'text', 'req' => true]], 'list' => ['nama']],
  'satuan' => ['title' => 'Satuan', 'table' => 'satuan',
    'fields' => ['nama' => ['Nama satuan', 'text', 'req' => true]], 'list' => ['nama']],
  'gudang' => ['title' => 'Gudang', 'table' => 'gudang',
    'fields' => [
      'kode' => ['Kode', 'text', 'req' => true], 'nama' => ['Nama gudang', 'text', 'req' => true],
      'alamat' => ['Alamat', 'textarea'],
    ],
    'list' => ['kode', 'nama', 'alamat']],
  'akun' => ['title' => 'Daftar akun', 'table' => 'akun',
    'fields' => [
      'kode' => ['Kode akun', 'text', 'req' => true], 'nama' => ['Nama akun', 'text', 'req' => true],
      'tipe' => ['Tipe', 'enum', 'req' => true, 'opts' => ['Aset', 'Kewajiban', 'Modal', 'Pendapatan', 'Beban']],
    ],
    'list' => ['kode', 'nama', 'tipe']],
];
