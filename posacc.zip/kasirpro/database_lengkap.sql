CREATE DATABASE IF NOT EXISTS pos_accurate CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE pos_accurate;

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL UNIQUE,
  nama VARCHAR(100) NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('manager','supervisor','kasir') NOT NULL DEFAULT 'kasir',
  aktif TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE kategori (id INT AUTO_INCREMENT PRIMARY KEY, nama VARCHAR(100) NOT NULL UNIQUE);
CREATE TABLE satuan   (id INT AUTO_INCREMENT PRIMARY KEY, nama VARCHAR(50) NOT NULL UNIQUE);
CREATE TABLE gudang (
  id INT AUTO_INCREMENT PRIMARY KEY, kode VARCHAR(20) NOT NULL UNIQUE,
  nama VARCHAR(100) NOT NULL, alamat TEXT NULL
);
CREATE TABLE pelanggan (
  id INT AUTO_INCREMENT PRIMARY KEY, kode VARCHAR(20) NOT NULL UNIQUE,
  nama VARCHAR(150) NOT NULL, telepon VARCHAR(30) NULL, email VARCHAR(100) NULL,
  alamat TEXT NULL, limit_piutang DECIMAL(15,2) NOT NULL DEFAULT 0
);
CREATE TABLE pemasok (
  id INT AUTO_INCREMENT PRIMARY KEY, kode VARCHAR(20) NOT NULL UNIQUE,
  nama VARCHAR(150) NOT NULL, telepon VARCHAR(30) NULL, email VARCHAR(100) NULL, alamat TEXT NULL
);
CREATE TABLE barang (
  id INT AUTO_INCREMENT PRIMARY KEY, kode VARCHAR(30) NOT NULL UNIQUE,
  nama VARCHAR(200) NOT NULL,
  kategori_id INT NULL, satuan_id INT NULL,
  harga_beli DECIMAL(15,2) NOT NULL DEFAULT 0,
  harga_jual DECIMAL(15,2) NOT NULL DEFAULT 0,
  stok_minimum DECIMAL(15,2) NOT NULL DEFAULT 0,
  FOREIGN KEY (kategori_id) REFERENCES kategori(id),
  FOREIGN KEY (satuan_id)   REFERENCES satuan(id)
);
CREATE TABLE akun (
  id INT AUTO_INCREMENT PRIMARY KEY, kode VARCHAR(20) NOT NULL UNIQUE,
  nama VARCHAR(150) NOT NULL,
  tipe ENUM('Aset','Kewajiban','Modal','Pendapatan','Beban') NOT NULL
);

INSERT INTO satuan (nama) VALUES ('Pcs'),('Box'),('Set'),('Kg'),('Liter');
INSERT INTO gudang (kode,nama) VALUES ('GD-01','Gudang Utama');
INSERT INTO akun (kode,nama,tipe) VALUES
 ('1-1000','Kas','Aset'),('1-1100','Bank','Aset'),('1-1200','Piutang Usaha','Aset'),
 ('1-1300','Persediaan Barang','Aset'),('2-1000','Hutang Usaha','Kewajiban'),
 ('3-1000','Modal Pemilik','Modal'),('4-1000','Penjualan','Pendapatan'),
 ('5-1000','Harga Pokok Penjualan','Beban'),('6-1000','Beban Operasional','Beban');

USE pos_accurate;

CREATE TABLE pengaturan (k VARCHAR(50) PRIMARY KEY, v TEXT NULL);
CREATE TABLE transaksi (
  id INT AUTO_INCREMENT PRIMARY KEY,
  tipe ENUM('jual','beli') NOT NULL,
  nomor VARCHAR(30) NOT NULL UNIQUE,
  tanggal DATE NOT NULL,
  kontak_id INT NULL,
  gudang_id INT NOT NULL,
  total DECIMAL(15,2) NOT NULL,
  dibayar DECIMAL(15,2) NOT NULL DEFAULT 0,
  catatan VARCHAR(255) NULL,
  status ENUM('aktif','batal') NOT NULL DEFAULT 'aktif',
  user_id INT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX (tipe, tanggal),
  FOREIGN KEY (gudang_id) REFERENCES gudang(id),
  FOREIGN KEY (user_id) REFERENCES users(id)
);
CREATE TABLE transaksi_item (
  id INT AUTO_INCREMENT PRIMARY KEY,
  transaksi_id INT NOT NULL, barang_id INT NOT NULL,
  qty DECIMAL(15,2) NOT NULL, harga DECIMAL(15,2) NOT NULL, subtotal DECIMAL(15,2) NOT NULL,
  FOREIGN KEY (transaksi_id) REFERENCES transaksi(id) ON DELETE CASCADE,
  FOREIGN KEY (barang_id) REFERENCES barang(id)
);
CREATE TABLE stok_log (
  id INT AUTO_INCREMENT PRIMARY KEY,
  barang_id INT NOT NULL, gudang_id INT NOT NULL,
  qty DECIMAL(15,2) NOT NULL,
  ref_tipe VARCHAR(10) NOT NULL, ref_id INT NULL,
  tanggal DATE NOT NULL, ket VARCHAR(255) NULL,
  INDEX (barang_id, gudang_id), INDEX (ref_tipe, ref_id),
  FOREIGN KEY (barang_id) REFERENCES barang(id),
  FOREIGN KEY (gudang_id) REFERENCES gudang(id)
);
CREATE TABLE pembayaran (
  id INT AUTO_INCREMENT PRIMARY KEY,
  transaksi_id INT NOT NULL, tanggal DATE NOT NULL, jumlah DECIMAL(15,2) NOT NULL,
  FOREIGN KEY (transaksi_id) REFERENCES transaksi(id) ON DELETE CASCADE
);
CREATE TABLE jurnal (
  id INT AUTO_INCREMENT PRIMARY KEY,
  tanggal DATE NOT NULL, ket VARCHAR(255) NOT NULL,
  ref_tipe VARCHAR(10) NULL, ref_id INT NULL,
  INDEX (tanggal), INDEX (ref_tipe, ref_id)
);
CREATE TABLE jurnal_detail (
  id INT AUTO_INCREMENT PRIMARY KEY,
  jurnal_id INT NOT NULL, akun_id INT NOT NULL,
  debit DECIMAL(15,2) NOT NULL DEFAULT 0, kredit DECIMAL(15,2) NOT NULL DEFAULT 0,
  FOREIGN KEY (jurnal_id) REFERENCES jurnal(id) ON DELETE CASCADE,
  FOREIGN KEY (akun_id) REFERENCES akun(id)
);

INSERT INTO pengaturan (k, v) VALUES
 ('nota_nama','Nama Usaha Anda'), ('nota_alamat','Alamat usaha'), ('nota_telp',''),
 ('nota_judul_jual','FAKTUR PENJUALAN'), ('nota_judul_beli','FAKTUR PEMBELIAN'),
 ('nota_footer','Terima kasih atas kunjungan Anda'), ('nota_catatan',''),
 ('nota_tampil_kasir','1'), ('nota_lebar','58'), ('nota_kertas','A5');

USE pos_accurate;

-- PPN pada transaksi
ALTER TABLE transaksi
  ADD COLUMN subtotal DECIMAL(15,2) NOT NULL DEFAULT 0 AFTER gudang_id,
  ADD COLUMN ppn_persen DECIMAL(5,2) NOT NULL DEFAULT 0 AFTER subtotal,
  ADD COLUMN ppn DECIMAL(15,2) NOT NULL DEFAULT 0 AFTER ppn_persen;
UPDATE transaksi SET subtotal = total;
ALTER TABLE pembayaran ADD COLUMN ket VARCHAR(80) NULL;

-- Harga bertingkat
ALTER TABLE barang
  ADD COLUMN harga_jual2 DECIMAL(15,2) NOT NULL DEFAULT 0 AFTER harga_jual,
  ADD COLUMN harga_jual3 DECIMAL(15,2) NOT NULL DEFAULT 0 AFTER harga_jual2;
ALTER TABLE pelanggan ADD COLUMN level_harga TINYINT NOT NULL DEFAULT 1;

-- Retur
CREATE TABLE retur (
  id INT AUTO_INCREMENT PRIMARY KEY,
  tipe ENUM('jual','beli') NOT NULL,
  nomor VARCHAR(30) NOT NULL UNIQUE,
  tanggal DATE NOT NULL,
  transaksi_id INT NOT NULL, gudang_id INT NOT NULL,
  subtotal DECIMAL(15,2) NOT NULL, ppn DECIMAL(15,2) NOT NULL DEFAULT 0, total DECIMAL(15,2) NOT NULL,
  potong DECIMAL(15,2) NOT NULL DEFAULT 0, refund DECIMAL(15,2) NOT NULL DEFAULT 0,
  catatan VARCHAR(255) NULL, user_id INT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX (tipe, tanggal),
  FOREIGN KEY (transaksi_id) REFERENCES transaksi(id),
  FOREIGN KEY (gudang_id) REFERENCES gudang(id),
  FOREIGN KEY (user_id) REFERENCES users(id)
);
CREATE TABLE retur_item (
  id INT AUTO_INCREMENT PRIMARY KEY,
  retur_id INT NOT NULL, barang_id INT NOT NULL,
  qty DECIMAL(15,2) NOT NULL, harga DECIMAL(15,2) NOT NULL, subtotal DECIMAL(15,2) NOT NULL,
  FOREIGN KEY (retur_id) REFERENCES retur(id) ON DELETE CASCADE,
  FOREIGN KEY (barang_id) REFERENCES barang(id)
);

-- Akun tambahan
INSERT IGNORE INTO akun (kode, nama, tipe) VALUES
 ('1-1400','PPN Masukan','Aset'),
 ('2-1100','PPN Keluaran','Kewajiban'),
 ('3-1100','Modal Saldo Awal','Modal'),
 ('5-1100','Selisih Persediaan','Beban');

INSERT IGNORE INTO pengaturan (k, v) VALUES ('ppn_aktif','0'), ('ppn_persen','11');
