<?php
require __DIR__ . '/config.php';
require __DIR__ . '/includes/layout.php';
require_login();
$pdo = db(); $ms = in_array(user()['role'], ['manager', 'supervisor'], true);
$one = function (string $sql, array $p = []) use ($pdo) { $s = $pdo->prepare($sql); $s->execute($p); return (float)$s->fetchColumn(); };
$hari = $one("SELECT COALESCE(SUM(total),0) FROM transaksi WHERE tipe='jual' AND status='aktif' AND tanggal=CURDATE()");
page_start('Dashboard', 'dashboard');
?>
<div class="panel">
  <h2>Ringkasan</h2>
  <table>
    <tr><td>Penjualan hari ini</td><td class="num"><?= rp($hari) ?></td></tr>
    <?php if ($ms):
      $bulan = $one("SELECT COALESCE(SUM(total),0) FROM transaksi WHERE tipe='jual' AND status='aktif' AND DATE_FORMAT(tanggal,'%Y-%m')=?", [date('Y-m')]);
      $beli = $one("SELECT COALESCE(SUM(total),0) FROM transaksi WHERE tipe='beli' AND status='aktif' AND DATE_FORMAT(tanggal,'%Y-%m')=?", [date('Y-m')]);
      $piutang = $one("SELECT COALESCE(SUM(total-dibayar),0) FROM transaksi WHERE tipe='jual' AND status='aktif'");
      $hutang = $one("SELECT COALESCE(SUM(total-dibayar),0) FROM transaksi WHERE tipe='beli' AND status='aktif'");
      $tipis = $one("SELECT COUNT(*) FROM (SELECT b.id FROM barang b LEFT JOIN stok_log s ON s.barang_id=b.id WHERE b.stok_minimum>0 GROUP BY b.id HAVING COALESCE(SUM(s.qty),0)<=MAX(b.stok_minimum)) x"); ?>
    <tr><td>Penjualan bulan ini</td><td class="num"><?= rp($bulan) ?></td></tr>
    <tr><td>Pembelian bulan ini</td><td class="num"><?= rp($beli) ?></td></tr>
    <tr><td><a href="laporan.php?j=piutang">Piutang belum dibayar</a></td><td class="num"><?= rp($piutang) ?></td></tr>
    <tr><td><a href="laporan.php?j=hutang">Hutang belum dibayar</a></td><td class="num"><?= rp($hutang) ?></td></tr>
    <tr><td><a href="stok.php">Barang di bawah stok minimum</a></td><td class="num"><?= (int)$tipis ?></td></tr>
    <?php endif; ?>
  </table>
</div>
<div class="panel"><a class="btn" href="transaksi.php?t=jual&baru=1">Buat penjualan baru</a></div>
<?php page_end();
