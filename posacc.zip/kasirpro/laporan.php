<?php
require __DIR__ . '/config.php';
require __DIR__ . '/includes/layout.php';
require_role(['manager', 'supervisor']);
$pdo = db(); $bulan = bulan_param();
$jenis = ['penjualan' => 'Laporan penjualan', 'pembelian' => 'Laporan pembelian', 'labarugi' => 'Laba rugi',
          'neraca' => 'Neraca', 'ppn' => 'Laporan PPN', 'piutang' => 'Piutang', 'hutang' => 'Hutang'];
$j = $_GET['j'] ?? 'penjualan'; if (!isset($jenis[$j])) $j = 'penjualan';
$from = $bulan . '-01'; $to = date('Y-m-t', strtotime($from));

function saldo(PDO $pdo, array $tipe, string $from, string $to): array {
    $in = implode(',', array_fill(0, count($tipe), '?'));
    $s = $pdo->prepare("SELECT a.kode,a.nama,a.tipe,COALESCE(SUM(x.debit),0) d,COALESCE(SUM(x.kredit),0) k FROM akun a
      LEFT JOIN (SELECT d.akun_id,d.debit,d.kredit FROM jurnal_detail d JOIN jurnal j ON j.id=d.jurnal_id WHERE j.tanggal BETWEEN ? AND ?) x ON x.akun_id=a.id
      WHERE a.tipe IN ($in) GROUP BY a.id ORDER BY a.kode");
    $s->execute(array_merge([$from, $to], $tipe));
    return $s->fetchAll();
}
function blok(string $judul, array $rows, bool $normalDebit, float &$sum): void {
    echo '<tr><th colspan="2">' . e($judul) . '</th></tr>'; $sum = 0;
    foreach ($rows as $r) {
        $v = $normalDebit ? $r['d'] - $r['k'] : $r['k'] - $r['d']; $sum += $v;
        echo '<tr><td style="padding-left:24px">' . e($r['kode'] . ' ' . $r['nama']) . '</td><td class="num">' . rp($v) . '</td></tr>';
    }
}

page_start($jenis[$j], 'laporan');
?>
<div class="panel no-print">
  <form method="get" class="search" style="max-width:none">
    <select name="j" style="max-width:200px"><?php foreach ($jenis as $k => $l) echo '<option value="' . $k . '"' . ($k === $j ? ' selected' : '') . '>' . e($l) . '</option>'; ?></select>
    <?php if (!in_array($j, ['piutang', 'hutang'], true)): ?><input type="month" name="bulan" value="<?= e($bulan) ?>" style="max-width:180px"><?php endif; ?>
    <button class="btn ghost">Tampilkan</button><button type="button" class="btn" onclick="window.print()">Cetak</button>
  </form>
</div>
<div class="panel">
  <div class="c"><h2 style="margin:0"><?= e(setting('nota_nama', APP_NAME)) ?></h2>
    <div><?= e($jenis[$j]) ?> &middot; <?= in_array($j, ['piutang', 'hutang'], true) ? 'per ' . date('d/m/Y')
      : ($j === 'neraca' ? 'per ' . tgl($to) : 'periode ' . tgl($from) . ' - ' . tgl($to)) ?></div></div>
  <div class="scroll"><table>
<?php
if ($j === 'penjualan' || $j === 'pembelian') {
    $tp = $j === 'penjualan' ? 'jual' : 'beli'; $kt = $j === 'penjualan' ? 'pelanggan' : 'pemasok';
    $s = $pdo->prepare("SELECT t.*, k.nama kontak FROM transaksi t LEFT JOIN `$kt` k ON k.id=t.kontak_id
      WHERE t.tipe=? AND t.status='aktif' AND t.tanggal BETWEEN ? AND ? ORDER BY t.tanggal, t.id");
    $s->execute([$tp, $from, $to]); $rows = $s->fetchAll(); $a = $b = 0;
    echo '<thead><tr><th>Tanggal</th><th>Nomor</th><th>' . ($tp === 'jual' ? 'Pelanggan' : 'Pemasok') . '</th><th class="num">Total</th><th class="num">Dibayar</th><th class="num">Sisa</th></tr></thead>';
    foreach ($rows as $r) { $a += $r['total']; $b += $r['dibayar'];
        echo '<tr><td>' . tgl($r['tanggal']) . '</td><td>' . e($r['nomor']) . '</td><td>' . e($r['kontak'] ?? 'Umum') . '</td><td class="num">' . rp($r['total']) . '</td><td class="num">' . rp($r['dibayar']) . '</td><td class="num">' . rp($r['total'] - $r['dibayar']) . '</td></tr>'; }
    if (!$rows) echo '<tr><td colspan="6" class="muted">Tidak ada transaksi pada periode ini.</td></tr>';
    echo '<tr><th colspan="3" class="num">Total (' . count($rows) . ' transaksi)</th><th class="num">' . rp($a) . '</th><th class="num">' . rp($b) . '</th><th class="num">' . rp($a - $b) . '</th></tr>';
    $ppnSum = array_sum(array_column($rows, 'ppn'));
    $rs = $pdo->prepare('SELECT COALESCE(SUM(total),0) FROM retur WHERE tipe=? AND tanggal BETWEEN ? AND ?');
    $rs->execute([$tp, $from, $to]); $ret = (float)$rs->fetchColumn();
    echo '<tr><td colspan="3" class="num">Termasuk PPN</td><td class="num">' . rp($ppnSum) . '</td><td colspan="2"></td></tr>';
    echo '<tr><td colspan="3" class="num">Retur pada periode</td><td class="num">- ' . rp($ret) . '</td><td colspan="2"></td></tr>';
    echo '<tr><th colspan="3" class="num">Total bersih</th><th class="num">' . rp($a - $ret) . '</th><td colspan="2"></td></tr>';
} elseif ($j === 'piutang' || $j === 'hutang') {
    $tp = $j === 'piutang' ? 'jual' : 'beli'; $kt = $j === 'piutang' ? 'pelanggan' : 'pemasok';
    $s = $pdo->prepare("SELECT t.*, k.nama kontak FROM transaksi t LEFT JOIN `$kt` k ON k.id=t.kontak_id
      WHERE t.tipe=? AND t.status='aktif' AND t.total-t.dibayar>0.005 ORDER BY t.tanggal, t.id");
    $s->execute([$tp]); $rows = $s->fetchAll(); $a = 0;
    echo '<thead><tr><th>Tanggal</th><th>Nomor</th><th>' . ($tp === 'jual' ? 'Pelanggan' : 'Pemasok') . '</th><th class="num">Umur (hari)</th><th class="num">Sisa</th></tr></thead>';
    foreach ($rows as $r) { $sisa = $r['total'] - $r['dibayar']; $a += $sisa;
        echo '<tr><td>' . tgl($r['tanggal']) . '</td><td><a href="detail.php?id=' . $r['id'] . '">' . e($r['nomor']) . '</a></td><td>' . e($r['kontak'] ?? '-') . '</td><td class="num">' . (int)((time() - strtotime($r['tanggal'])) / 86400) . '</td><td class="num">' . rp($sisa) . '</td></tr>'; }
    if (!$rows) echo '<tr><td colspan="5" class="muted">Tidak ada yang belum dibayar.</td></tr>';
    echo '<tr><th colspan="4" class="num">Total</th><th class="num">' . rp($a) . '</th></tr>';
} elseif ($j === 'ppn') {
    $net = function (string $kode, bool $debitNormal) use ($pdo, $from, $to) {
        $s = $pdo->prepare('SELECT COALESCE(SUM(d.debit),0) d, COALESCE(SUM(d.kredit),0) k FROM jurnal_detail d JOIN jurnal j ON j.id=d.jurnal_id JOIN akun a ON a.id=d.akun_id WHERE a.kode=? AND j.tanggal BETWEEN ? AND ?');
        $s->execute([$kode, $from, $to]); $r = $s->fetch();
        return $debitNormal ? $r['d'] - $r['k'] : $r['k'] - $r['d'];
    };
    $keluar = $net('2-1100', false); $masuk = $net('1-1400', true);
    echo '<tr><td>PPN keluaran (penjualan, setelah retur)</td><td class="num">' . rp($keluar) . '</td></tr>';
    echo '<tr><td>PPN masukan (pembelian, setelah retur)</td><td class="num">' . rp($masuk) . '</td></tr>';
    echo '<tr><th>PPN ' . ($keluar - $masuk >= 0 ? 'kurang bayar' : 'lebih bayar') . '</th><th class="num">' . rp(abs($keluar - $masuk)) . '</th></tr>';
} elseif ($j === 'labarugi') {
    $p = saldo($pdo, ['Pendapatan'], $from, $to); $b = saldo($pdo, ['Beban'], $from, $to);
    blok('Pendapatan', $p, false, $sp); blok('Beban', $b, true, $sb);
    echo '<tr><th>Laba (rugi) bersih</th><th class="num">' . rp($sp - $sb) . '</th></tr>';
} else {
    $all = '1970-01-01';
    blok('Aset', saldo($pdo, ['Aset'], $all, $to), true, $sa);
    blok('Kewajiban', saldo($pdo, ['Kewajiban'], $all, $to), false, $sk);
    blok('Modal', saldo($pdo, ['Modal'], $all, $to), false, $sm);
    $laba = 0; foreach (saldo($pdo, ['Pendapatan'], $all, $to) as $r) $laba += $r['k'] - $r['d'];
    foreach (saldo($pdo, ['Beban'], $all, $to) as $r) $laba -= $r['d'] - $r['k'];
    echo '<tr><td style="padding-left:24px">Laba berjalan</td><td class="num">' . rp($laba) . '</td></tr>';
    echo '<tr><th>Total aset</th><th class="num">' . rp($sa) . '</th></tr>';
    echo '<tr><th>Total kewajiban + modal</th><th class="num">' . rp($sk + $sm + $laba) . '</th></tr>';
}
?>
  </table></div>
</div>
<?php page_end();
