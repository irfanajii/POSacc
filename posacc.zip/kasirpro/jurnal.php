<?php
require __DIR__ . '/config.php';
require __DIR__ . '/includes/layout.php';
require_role(['manager', 'supervisor']);
$pdo = db(); $bulan = bulan_param(); $role = user()['role'];
$akun = $pdo->query('SELECT id,kode,nama FROM akun ORDER BY kode')->fetchAll();
$kodeById = array_column($akun, 'kode', 'id');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check(); $act = $_POST['action'] ?? ''; $back = $bulan;
    if ($act === 'hapus') {
        if ($role !== 'manager') { http_response_code(403); exit('Hanya Manager yang boleh menghapus jurnal.'); }
        $pdo->prepare("DELETE FROM jurnal WHERE id=? AND ref_tipe='manual'")->execute([(int)($_POST['id'] ?? 0)]);
        flash('Jurnal dihapus.');
    } elseif ($act === 'manual') {
        $tgl = $_POST['tanggal'] ?? '';
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $tgl)) $tgl = date('Y-m-d');
        $back = substr($tgl, 0, 7); $ket = trim($_POST['ket'] ?? ''); $lines = []; $sd = $sk = 0;
        foreach (($_POST['akun'] ?? []) as $i => $aid) {
            $aid = (int)$aid; $d = round(max(0, (float)($_POST['debit'][$i] ?? 0)), 2); $k = round(max(0, (float)($_POST['kredit'][$i] ?? 0)), 2);
            if (isset($kodeById[$aid]) && ($d > 0 || $k > 0)) { $lines[] = [$kodeById[$aid], $d, $k]; $sd += $d; $sk += $k; }
        }
        if ($ket === '' || count($lines) < 2) flash('Isi keterangan dan minimal dua baris akun.', 'err');
        elseif (abs($sd - $sk) > 0.005) flash('Total debit dan kredit harus sama.', 'err');
        else {
            try { $pdo->beginTransaction(); post_jurnal($tgl, $ket, 'manual', 0, $lines); $pdo->commit(); flash('Jurnal tersimpan.'); }
            catch (Throwable $ex) { if ($pdo->inTransaction()) $pdo->rollBack(); flash('Jurnal gagal disimpan.', 'err'); }
        }
    }
    header('Location: jurnal.php?bulan=' . $back); exit;
}

$st = $pdo->prepare("SELECT j.id,j.tanggal,j.ket,j.ref_tipe,a.kode,a.nama,d.debit,d.kredit FROM jurnal j
  JOIN jurnal_detail d ON d.jurnal_id=j.id JOIN akun a ON a.id=d.akun_id
  WHERE DATE_FORMAT(j.tanggal,'%Y-%m')=? ORDER BY j.tanggal, j.id, d.id");
$st->execute([$bulan]);
$rows = $st->fetchAll(); $td = $tk = 0;
page_start('Jurnal umum', 'jurnal');
?>
<div class="panel no-print">
  <details><summary><b>Buat jurnal manual</b></summary>
  <form method="post" style="margin-top:12px">
    <input type="hidden" name="csrf" value="<?= e(csrf()) ?>"><input type="hidden" name="action" value="manual">
    <div class="grid"><label>Tanggal<input type="date" name="tanggal" value="<?= date('Y-m-d') ?>" required></label>
      <label>Keterangan<input name="ket" maxlength="255" required></label></div>
    <div class="scroll"><table class="items"><thead><tr><th>Akun</th><th>Debit</th><th>Kredit</th><th></th></tr></thead><tbody id="jr"></tbody></table></div>
    <p class="actions"><button type="button" class="btn ghost" id="jadd">Tambah baris</button><span id="jsel" class="muted"></span></p>
    <p><button class="btn">Simpan jurnal</button></p>
  </form></details>
</div>
<div class="panel">
  <form method="get" class="search no-print"><input type="month" name="bulan" value="<?= e($bulan) ?>">
    <button class="btn ghost">Tampilkan</button><button type="button" class="btn" onclick="window.print()">Cetak</button></form>
  <div class="scroll"><table>
    <thead><tr><th>Tanggal</th><th>Keterangan</th><th>Akun</th><th class="num">Debit</th><th class="num">Kredit</th><th class="no-print"></th></tr></thead>
    <?php $prev = null; foreach ($rows as $r): $td += $r['debit']; $tk += $r['kredit']; $new = $prev !== $r['id']; $prev = $r['id']; ?>
      <tr><td><?= $new ? tgl($r['tanggal']) : '' ?></td><td><?= $new ? e($r['ket']) : '' ?></td>
        <td style="<?= $r['kredit'] > 0 ? 'padding-left:28px' : '' ?>"><?= e($r['kode'] . ' ' . $r['nama']) ?></td>
        <td class="num"><?= $r['debit'] > 0 ? rp($r['debit']) : '' ?></td><td class="num"><?= $r['kredit'] > 0 ? rp($r['kredit']) : '' ?></td>
        <td class="act no-print"><?php if ($new && $r['ref_tipe'] === 'manual' && $role === 'manager'): ?>
          <form method="post" onsubmit="return confirm('Hapus jurnal manual ini?')"><input type="hidden" name="csrf" value="<?= e(csrf()) ?>">
          <input type="hidden" name="action" value="hapus"><input type="hidden" name="id" value="<?= $r['id'] ?>">
          <button class="link danger">Hapus</button></form><?php endif; ?></td></tr>
    <?php endforeach; ?>
    <?php if (!$rows): ?><tr><td colspan="6" class="muted">Belum ada jurnal di bulan ini.</td></tr><?php endif; ?>
    <tr><th colspan="3" class="num">Total</th><th class="num"><?= rp($td) ?></th><th class="num"><?= rp($tk) ?></th><th class="no-print"></th></tr>
  </table></div>
</div>
<script>
const A = <?= json_encode($akun, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
const jr = document.getElementById('jr');
function jrow() {
  const tr = document.createElement('tr');
  tr.innerHTML = '<td><select name="akun[]"></select></td><td><input type="number" name="debit[]" step="any" min="0"></td><td><input type="number" name="kredit[]" step="any" min="0"></td><td><button type="button" class="link danger">Hapus</button></td>';
  const sel = tr.querySelector('select'); sel.add(new Option('Pilih akun', ''));
  A.forEach(a => sel.add(new Option(a.kode + ' ' + a.nama, a.id)));
  tr.querySelector('button').onclick = () => { tr.remove(); jsum(); };
  tr.oninput = jsum; jr.appendChild(tr);
}
function jsum() {
  let d = 0, k = 0;
  jr.querySelectorAll('tr').forEach(tr => { const i = tr.querySelectorAll('input'); d += +i[0].value || 0; k += +i[1].value || 0; });
  document.getElementById('jsel').textContent = 'Debit ' + d.toLocaleString('id-ID') + ' | Kredit ' + k.toLocaleString('id-ID') + (Math.abs(d - k) < 0.005 ? ' (seimbang)' : ' (belum seimbang)');
}
document.getElementById('jadd').onclick = jrow; jrow(); jrow(); jsum();
</script>
<?php page_end();
