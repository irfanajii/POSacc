USE pos_accurate;

CREATE TABLE pengaturan (k VARCHAR(50) PRIMARY KEY, v TEXT NULL);
CREATE TABLE transaksi (
  id INT AUTO_INCREMENT PRIMARY KEY,
  tipe ENUM('jual','beli') NOT NULL,
  nomor VARCHAR(30) NOT NULL UNIQUE,
  tanggal DATE NOT NULL,
  kontak_id INT NULL,
  gudang_id INT NOT NULL,
  total DECIMAL(15,2) NOT NULL,
  dibayar DECIMAL(15,2) NOT NULL DEFAULT 0,
  catatan VARCHAR(255) NULL,
  status ENUM('aktif','batal') NOT NULL DEFAULT 'aktif',
  user_id INT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX (tipe, tanggal),
  FOREIGN KEY (gudang_id) REFERENCES gudang(id),
  FOREIGN KEY (user_id) REFERENCES users(id)
);
CREATE TABLE transaksi_item (
  id INT AUTO_INCREMENT PRIMARY KEY,
  transaksi_id INT NOT NULL, barang_id INT NOT NULL,
  qty DECIMAL(15,2) NOT NULL, harga DECIMAL(15,2) NOT NULL, subtotal DECIMAL(15,2) NOT NULL,
  FOREIGN KEY (transaksi_id) REFERENCES transaksi(id) ON DELETE CASCADE,
  FOREIGN KEY (barang_id) REFERENCES barang(id)
);
CREATE TABLE stok_log (
  id INT AUTO_INCREMENT PRIMARY KEY,
  barang_id INT NOT NULL, gudang_id INT NOT NULL,
  qty DECIMAL(15,2) NOT NULL,
  ref_tipe VARCHAR(10) NOT NULL, ref_id INT NULL,
  tanggal DATE NOT NULL, ket VARCHAR(255) NULL,
  INDEX (barang_id, gudang_id), INDEX (ref_tipe, ref_id),
  FOREIGN KEY (barang_id) REFERENCES barang(id),
  FOREIGN KEY (gudang_id) REFERENCES gudang(id)
);
CREATE TABLE pembayaran (
  id INT AUTO_INCREMENT PRIMARY KEY,
  transaksi_id INT NOT NULL, tanggal DATE NOT NULL, jumlah DECIMAL(15,2) NOT NULL,
  FOREIGN KEY (transaksi_id) REFERENCES transaksi(id) ON DELETE CASCADE
);
CREATE TABLE jurnal (
  id INT AUTO_INCREMENT PRIMARY KEY,
  tanggal DATE NOT NULL, ket VARCHAR(255) NOT NULL,
  ref_tipe VARCHAR(10) NULL, ref_id INT NULL,
  INDEX (tanggal), INDEX (ref_tipe, ref_id)
);
CREATE TABLE jurnal_detail (
  id INT AUTO_INCREMENT PRIMARY KEY,
  jurnal_id INT NOT NULL, akun_id INT NOT NULL,
  debit DECIMAL(15,2) NOT NULL DEFAULT 0, kredit DECIMAL(15,2) NOT NULL DEFAULT 0,
  FOREIGN KEY (jurnal_id) REFERENCES jurnal(id) ON DELETE CASCADE,
  FOREIGN KEY (akun_id) REFERENCES akun(id)
);

INSERT INTO pengaturan (k, v) VALUES
 ('nota_nama','Nama Usaha Anda'), ('nota_alamat','Alamat usaha'), ('nota_telp',''),
 ('nota_judul_jual','FAKTUR PENJUALAN'), ('nota_judul_beli','FAKTUR PEMBELIAN'),
 ('nota_footer','Terima kasih atas kunjungan Anda'), ('nota_catatan',''),
 ('nota_tampil_kasir','1'), ('nota_lebar','58'), ('nota_kertas','A5');
