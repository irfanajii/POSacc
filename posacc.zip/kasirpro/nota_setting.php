<?php
require __DIR__ . '/config.php';
require __DIR__ . '/includes/layout.php';
require_role(['manager', 'supervisor']);
$text = ['nota_nama' => 'Nama usaha', 'nota_telp' => 'Telepon', 'nota_judul_jual' => 'Judul nota besar penjualan',
         'nota_judul_beli' => 'Judul nota besar pembelian'];
$area = ['nota_alamat' => 'Alamat', 'nota_footer' => 'Teks penutup', 'nota_catatan' => 'Catatan di nota besar (mis. syarat pembayaran)'];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    foreach (array_merge($text, $area) as $k => $_) set_setting($k, trim($_POST[$k] ?? ''));
    set_setting('nota_tampil_kasir', isset($_POST['nota_tampil_kasir']) ? '1' : '0');
    set_setting('nota_lebar', ($_POST['nota_lebar'] ?? '') === '80' ? '80' : '58');
    set_setting('nota_kertas', ($_POST['nota_kertas'] ?? '') === 'A4' ? 'A4' : 'A5');
    flash('Pengaturan nota tersimpan.');
    header('Location: nota_setting.php'); exit;
}
$last = db()->query("SELECT id FROM transaksi WHERE tipe='jual' ORDER BY id DESC LIMIT 1")->fetchColumn();
page_start('Desain nota', 'nota_setting');
?>
<div class="panel">
  <form method="post" class="grid">
    <input type="hidden" name="csrf" value="<?= e(csrf()) ?>">
    <?php foreach ($text as $k => $l): ?><label><?= e($l) ?><input name="<?= $k ?>" value="<?= e(setting($k)) ?>"></label><?php endforeach; ?>
    <?php foreach ($area as $k => $l): ?><label><?= e($l) ?><textarea name="<?= $k ?>" rows="3"><?= e(setting($k)) ?></textarea></label><?php endforeach; ?>
    <label>Lebar kertas nota kecil<select name="nota_lebar">
      <option value="58" <?= setting('nota_lebar', '58') === '58' ? 'selected' : '' ?>>58 mm</option>
      <option value="80" <?= setting('nota_lebar') === '80' ? 'selected' : '' ?>>80 mm</option></select></label>
    <label>Ukuran kertas nota besar<select name="nota_kertas">
      <option value="A5" <?= setting('nota_kertas', 'A5') === 'A5' ? 'selected' : '' ?>>A5</option>
      <option value="A4" <?= setting('nota_kertas') === 'A4' ? 'selected' : '' ?>>A4</option></select></label>
    <label><span><input type="checkbox" name="nota_tampil_kasir" style="width:auto" <?= setting('nota_tampil_kasir', '1') === '1' ? 'checked' : '' ?>> Tampilkan nama kasir</span></label>
    <div class="actions"><button class="btn">Simpan</button>
    <?php if ($last): ?><a class="btn ghost" target="_blank" href="nota.php?id=<?= $last ?>&u=kecil">Pratinjau kecil</a>
      <a class="btn ghost" target="_blank" href="nota.php?id=<?= $last ?>&u=besar">Pratinjau besar</a><?php endif; ?></div>
  </form>
</div>
<?php page_end();
