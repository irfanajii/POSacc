<?php
require __DIR__ . '/config.php';
require __DIR__ . '/includes/layout.php';
require_login();
$pdo = db(); $canAdj = in_array(user()['role'], ['manager', 'supervisor'], true);
$gudang = $pdo->query('SELECT id,nama FROM gudang ORDER BY id')->fetchAll(PDO::FETCH_KEY_PAIR);
$pemasok = $pdo->query('SELECT id,nama FROM pemasok ORDER BY nama')->fetchAll(PDO::FETCH_KEY_PAIR);
$pelanggan = $pdo->query('SELECT id,nama FROM pelanggan ORDER BY nama')->fetchAll(PDO::FETCH_KEY_PAIR);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    if (!$canAdj) { http_response_code(403); exit('Anda tidak boleh menyesuaikan stok.'); }
    $bid = (int)($_POST['barang_id'] ?? 0); $gid = (int)($_POST['gudang_id'] ?? 0); $q = (float)($_POST['qty'] ?? 0);
    $ket = trim($_POST['ket'] ?? '') ?: 'Penyesuaian stok';
    if (!$bid || !isset($gudang[$gid]) || $q == 0) flash('Pilih barang dan gudang, isi jumlah (boleh minus).', 'err');
    elseif ($q < 0 && stok($bid, $gid) + $q < 0) flash('Stok tidak boleh menjadi minus.', 'err');
    else {
        try {
            $pdo->beginTransaction();
            $pdo->prepare('INSERT INTO stok_log (barang_id,gudang_id,qty,ref_tipe,tanggal,ket) VALUES (?,?,?,"adj",CURDATE(),?)')->execute([$bid, $gid, $q, $ket]);
            $lid = (int)$pdo->lastInsertId();
            $hb = $pdo->prepare('SELECT harga_beli FROM barang WHERE id=?'); $hb->execute([$bid]);
            $nilai = round(abs($q) * (float)$hb->fetchColumn(), 2);
            $ctr = isset($_POST['stok_awal']) ? '3-1100' : '5-1100';
            post_jurnal(date('Y-m-d'), 'Penyesuaian stok: ' . $ket, 'adj', $lid,
                $q > 0 ? [['1-1300', $nilai, 0], [$ctr, 0, $nilai]] : [[$ctr, $nilai, 0], ['1-1300', 0, $nilai]]);
            $pdo->commit(); flash('Stok disesuaikan dan jurnal dibuat.');
        } catch (Throwable $ex) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            flash('Penyesuaian gagal disimpan.', 'err');
        }
    }
    header('Location: stok.php'); exit;
}

if (isset($_GET['kartu'])) {
    $bid = (int)$_GET['kartu'];
    $b = $pdo->prepare('SELECT kode,nama FROM barang WHERE id=?'); $b->execute([$bid]); $b = $b->fetch();
    if (!$b) { http_response_code(404); exit('Barang tidak ditemukan.'); }
    $l = $pdo->prepare('SELECT l.*, g.nama gudang FROM stok_log l JOIN gudang g ON g.id=l.gudang_id WHERE l.barang_id=? ORDER BY l.tanggal DESC, l.id DESC LIMIT 300');
    $l->execute([$bid]);
    page_start('Kartu stok: ' . $b['nama'], 'stok'); ?>
    <div class="panel"><p><a href="stok.php">&larr; Kembali</a></p><div class="scroll"><table>
      <thead><tr><th>Tanggal</th><th>Gudang</th><th>Keterangan</th><th class="num">Masuk/keluar</th></tr></thead>
      <?php foreach ($l->fetchAll() as $r): ?><tr><td><?= tgl($r['tanggal']) ?></td><td><?= e($r['gudang']) ?></td><td><?= e($r['ket']) ?></td>
        <td class="num"><?= ($r['qty'] > 0 ? '+' : '') . qf($r['qty']) ?></td></tr><?php endforeach; ?>
    </table></div></div>
    <?php page_end(); exit;
}

$q = trim($_GET['q'] ?? ''); $g = (int)($_GET['gudang'] ?? 0);
$sp = (int)($_GET['pemasok'] ?? 0); $pl = (int)($_GET['pelanggan'] ?? 0);
$p = []; $sql = 'SELECT b.id,b.kode,b.nama,b.stok_minimum,s.nama satuan,COALESCE(SUM(sl.qty),0) stok FROM barang b
  LEFT JOIN satuan s ON s.id=b.satuan_id LEFT JOIN stok_log sl ON sl.barang_id=b.id';
if ($g) { $sql .= ' AND sl.gudang_id=?'; $p[] = $g; }
$sql .= ' WHERE 1=1';
if ($q !== '') { $sql .= ' AND (b.nama LIKE ? OR b.kode LIKE ?)'; array_push($p, "%$q%", "%$q%"); }
foreach ([['beli', $sp], ['jual', $pl]] as [$tp, $kid]) if ($kid) {
    $sql .= " AND b.id IN (SELECT ti.barang_id FROM transaksi_item ti JOIN transaksi t ON t.id=ti.transaksi_id WHERE t.tipe='$tp' AND t.status='aktif' AND t.kontak_id=?)";
    $p[] = $kid;
}
$sql .= ' GROUP BY b.id ORDER BY b.nama';
$st = $pdo->prepare($sql); $st->execute($p); $data = $st->fetchAll();
$barang = $pdo->query('SELECT id,kode,nama FROM barang ORDER BY nama')->fetchAll();
page_start('Stok barang', 'stok');
$opt = fn(array $a, int $sel, string $all) => '<option value="">' . $all . '</option>' . implode('', array_map(
    fn($id, $nm) => '<option value="' . $id . '"' . ($id == $sel ? ' selected' : '') . '>' . e($nm) . '</option>', array_keys($a), $a));
?>
<div class="panel">
  <form method="get" class="grid">
    <label>Cari<input name="q" value="<?= e($q) ?>" placeholder="Nama atau kode"></label>
    <label>Gudang<select name="gudang"><?= $opt($gudang, $g, 'Semua gudang') ?></select></label>
    <label>Barang dari pemasok<select name="pemasok"><?= $opt($pemasok, $sp, 'Semua') ?></select></label>
    <label>Barang dijual ke pelanggan<select name="pelanggan"><?= $opt($pelanggan, $pl, 'Semua') ?></select></label>
    <div class="actions"><button class="btn">Terapkan</button><button type="button" class="btn ghost" onclick="window.print()">Cetak</button></div>
  </form>
</div>
<div class="panel"><div class="scroll"><table>
  <thead><tr><th>Kode</th><th>Nama</th><th class="num">Stok</th><th>Satuan</th><th>Minimum</th><th class="no-print"></th></tr></thead>
  <?php foreach ($data as $r): $low = $r['stok_minimum'] > 0 && $r['stok'] <= $r['stok_minimum']; ?>
    <tr><td><?= e($r['kode']) ?></td><td><?= e($r['nama']) ?></td>
      <td class="num <?= $low ? 'low' : '' ?>"><?= qf($r['stok']) ?></td><td><?= e($r['satuan'] ?? '') ?></td>
      <td><?= qf($r['stok_minimum']) ?></td><td class="no-print"><a href="stok.php?kartu=<?= $r['id'] ?>">Kartu stok</a></td></tr>
  <?php endforeach; ?>
  <?php if (!$data): ?><tr><td colspan="6" class="muted">Tidak ada barang yang cocok.</td></tr><?php endif; ?>
</table></div></div>
<?php if ($canAdj): ?>
<div class="panel no-print"><h2>Penyesuaian stok</h2>
  <form method="post" class="grid">
    <input type="hidden" name="csrf" value="<?= e(csrf()) ?>">
    <label>Barang<select name="barang_id"><option value="">Pilih barang</option>
      <?php foreach ($barang as $b) echo '<option value="' . $b['id'] . '">' . e($b['kode'] . ' - ' . $b['nama']) . '</option>'; ?></select></label>
    <label>Gudang<select name="gudang_id"><?= $opt($gudang, 0, 'Pilih gudang') ?></select></label>
    <label>Jumlah (+ tambah, - kurangi)<input type="number" name="qty" step="any" required></label>
    <label>Keterangan<input name="ket" placeholder="Mis. hasil stok opname"></label>
    <label><span><input type="checkbox" name="stok_awal" style="width:auto"> Ini stok awal (bukan selisih)</span></label>
    <div class="actions"><button class="btn">Simpan penyesuaian</button></div>
  </form>
</div>
<?php endif; page_end();
