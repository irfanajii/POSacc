<?php
require __DIR__ . '/config.php';
require __DIR__ . '/includes/layout.php';
require_login();
$pdo = db(); $id = (int)($_GET['id'] ?? 0); $role = user()['role'];
$s = $pdo->prepare('SELECT t.*, u.nama kasir, g.nama gudang FROM transaksi t JOIN users u ON u.id=t.user_id JOIN gudang g ON g.id=t.gudang_id WHERE t.id=?');
$s->execute([$id]); $tr = $s->fetch();
if (!$tr) { http_response_code(404); exit('Transaksi tidak ditemukan.'); }
$jual = $tr['tipe'] === 'jual';
if (!$jual) require_role(['manager', 'supervisor']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $act = $_POST['action'] ?? ''; $sisa = round($tr['total'] - $tr['dibayar'], 2);
    try {
        if ($act === 'bayar' && $tr['status'] === 'aktif') {
            $j = round((float)($_POST['jumlah'] ?? 0), 2);
            if ($j <= 0 || $j > $sisa) { flash('Jumlah harus lebih dari 0 dan tidak melebihi sisa ' . rp($sisa) . '.', 'err'); }
            else {
                $pdo->beginTransaction();
                $pdo->prepare('INSERT INTO pembayaran (transaksi_id,tanggal,jumlah) VALUES (?,CURDATE(),?)')->execute([$id, $j]);
                $pdo->prepare('UPDATE transaksi SET dibayar=dibayar+? WHERE id=?')->execute([$j, $id]);
                $ket = ($jual ? 'Pelunasan piutang ' : 'Pelunasan hutang ') . $tr['nomor'];
                post_jurnal(date('Y-m-d'), $ket, 'bayar', $id, $jual
                    ? [['1-1000', $j, 0], ['1-1200', 0, $j]] : [['2-1000', $j, 0], ['1-1000', 0, $j]]);
                $pdo->commit(); flash('Pembayaran dicatat.');
            }
        } elseif ($act === 'batal' && $role === 'manager' && $tr['status'] === 'aktif') {
            $ok = true;
            $rc = $pdo->prepare('SELECT COUNT(*) FROM retur WHERE transaksi_id=?'); $rc->execute([$id]);
            if ($rc->fetchColumn() > 0) $ok = false;
            if (!$jual) { // pembelian: stok harus masih cukup untuk ditarik kembali
                $it = $pdo->prepare('SELECT barang_id, SUM(qty) q FROM transaksi_item WHERE transaksi_id=? GROUP BY barang_id');
                $it->execute([$id]);
                foreach ($it->fetchAll() as $r) if (stok((int)$r['barang_id'], (int)$tr['gudang_id']) < $r['q']) $ok = false;
            }
            if (!$ok) flash('Transaksi tidak bisa dibatalkan karena sudah ada retur atau stok sudah terpakai.', 'err');
            else {
                $pdo->beginTransaction();
                $pdo->prepare("UPDATE transaksi SET status='batal' WHERE id=?")->execute([$id]);
                $pdo->prepare('DELETE FROM stok_log WHERE ref_tipe=? AND ref_id=?')->execute([$tr['tipe'], $id]);
                $pdo->prepare('DELETE FROM jurnal WHERE ref_tipe IN (?, "bayar") AND ref_id=?')->execute([$tr['tipe'], $id]);
                $pdo->commit(); flash('Transaksi dibatalkan. Stok dan jurnal dikembalikan.');
            }
        }
    } catch (Throwable $ex) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        flash('Terjadi kesalahan. Coba lagi.', 'err');
    }
    header('Location: detail.php?id=' . $id); exit;
}

$items = $pdo->prepare('SELECT i.*, b.kode, b.nama FROM transaksi_item i JOIN barang b ON b.id=i.barang_id WHERE i.transaksi_id=?');
$items->execute([$id]); $items = $items->fetchAll();
$pay = $pdo->prepare('SELECT * FROM pembayaran WHERE transaksi_id=? ORDER BY id'); $pay->execute([$id]); $pay = $pay->fetchAll();
$kn = 'Umum';
if ($tr['kontak_id']) { $q = $pdo->prepare('SELECT nama FROM ' . ($jual ? 'pelanggan' : 'pemasok') . ' WHERE id=?'); $q->execute([$tr['kontak_id']]); $kn = $q->fetchColumn() ?: '-'; }
$sisa = round($tr['total'] - $tr['dibayar'], 2);
page_start(($jual ? 'Penjualan ' : 'Pembelian ') . $tr['nomor'], $tr['tipe']);
?>
<div class="panel">
  <table>
    <tr><td>Tanggal</td><td><?= tgl($tr['tanggal']) ?></td><td><?= $jual ? 'Pelanggan' : 'Pemasok' ?></td><td><?= e($kn) ?></td></tr>
    <tr><td>Gudang</td><td><?= e($tr['gudang']) ?></td><td>Dibuat oleh</td><td><?= e($tr['kasir']) ?></td></tr>
    <tr><td>Status</td><td><?= $tr['status'] === 'batal' ? 'Batal' : ($sisa > 0.005 ? 'Belum lunas' : 'Lunas') ?></td><td>Catatan</td><td><?= e($tr['catatan'] ?? '-') ?></td></tr>
  </table>
</div>
<div class="panel"><div class="scroll"><table>
  <thead><tr><th>Barang</th><th class="num">Jumlah</th><th class="num">Harga</th><th class="num">Subtotal</th></tr></thead>
  <?php foreach ($items as $i): ?>
    <tr><td><?= e($i['kode'] . ' - ' . $i['nama']) ?></td><td class="num"><?= qf($i['qty']) ?></td><td class="num"><?= rp($i['harga']) ?></td><td class="num"><?= rp($i['subtotal']) ?></td></tr>
  <?php endforeach; ?>
  <?php if ($tr['ppn'] > 0): ?>
  <tr><td colspan="3" class="num">Subtotal</td><td class="num"><?= rp($tr['subtotal']) ?></td></tr>
  <tr><td colspan="3" class="num">PPN <?= qf($tr['ppn_persen']) ?>%</td><td class="num"><?= rp($tr['ppn']) ?></td></tr>
  <?php endif; ?>
  <tr><th colspan="3" class="num">Total</th><th class="num"><?= rp($tr['total']) ?></th></tr>
  <tr><td colspan="3" class="num">Dibayar</td><td class="num"><?= rp($tr['dibayar']) ?></td></tr>
  <tr><td colspan="3" class="num">Sisa</td><td class="num"><?= rp($sisa) ?></td></tr>
</table></div></div>
<div class="panel actions">
  <a class="btn" target="_blank" href="nota.php?id=<?= $id ?>&u=kecil">Cetak nota kecil</a>
  <a class="btn ghost" target="_blank" href="nota.php?id=<?= $id ?>&u=besar">Cetak nota besar</a>
  <?php if ($tr['status'] === 'aktif' && in_array($role, ['manager', 'supervisor'], true)): ?>
    <a class="btn ghost" href="retur.php?trx=<?= $id ?>">Buat retur</a><?php endif; ?>
  <?php if ($role === 'manager' && $tr['status'] === 'aktif'): ?>
  <form method="post" onsubmit="return confirm('Batalkan transaksi ini? Stok dan jurnal akan dikembalikan.')">
    <input type="hidden" name="csrf" value="<?= e(csrf()) ?>"><input type="hidden" name="action" value="batal">
    <button class="btn ghost danger">Batalkan transaksi</button></form>
  <?php endif; ?>
</div>
<?php if ($tr['status'] === 'aktif' && $sisa > 0.005): ?>
<div class="panel"><h2><?= $jual ? 'Terima pembayaran piutang' : 'Bayar hutang' ?></h2>
  <form method="post" class="search">
    <input type="hidden" name="csrf" value="<?= e(csrf()) ?>"><input type="hidden" name="action" value="bayar">
    <input type="number" name="jumlah" step="any" min="0" max="<?= $sisa ?>" value="<?= $sisa ?>" required>
    <button class="btn">Catat pembayaran</button>
  </form>
</div>
<?php endif; ?>
<?php if ($pay): ?><div class="panel"><h2>Riwayat pembayaran lanjutan</h2><table>
  <?php foreach ($pay as $p): ?><tr><td><?= tgl($p['tanggal']) ?></td><td class="num"><?= rp($p['jumlah']) ?></td><td><?= e($p['ket'] ?? 'Pembayaran') ?></td></tr><?php endforeach; ?>
</table></div><?php endif; ?>
<?php $rt = $pdo->prepare('SELECT * FROM retur WHERE transaksi_id=? ORDER BY id'); $rt->execute([$id]); $rt = $rt->fetchAll();
if ($rt): ?><div class="panel"><h2>Retur</h2><table>
  <?php foreach ($rt as $r): ?><tr><td><a href="retur.php?id=<?= $r['id'] ?>"><?= e($r['nomor']) ?></a></td><td><?= tgl($r['tanggal']) ?></td><td class="num"><?= rp($r['total']) ?></td></tr><?php endforeach; ?>
</table></div><?php endif; ?>
<?php page_end();
