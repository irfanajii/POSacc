<?php
require __DIR__ . '/config.php';
require __DIR__ . '/includes/lib.php';
require_login();
$pdo = db(); $id = (int)($_GET['id'] ?? 0);
$besar = ($_GET['u'] ?? 'kecil') === 'besar';
$s = $pdo->prepare('SELECT t.*, u.nama kasir FROM transaksi t JOIN users u ON u.id=t.user_id WHERE t.id=?');
$s->execute([$id]); $t = $s->fetch();
if (!$t) { http_response_code(404); exit('Transaksi tidak ditemukan.'); }
$jual = $t['tipe'] === 'jual';
if (!$jual) require_role(['manager', 'supervisor']);
$kn = 'Umum';
if ($t['kontak_id']) { $q = $pdo->prepare('SELECT nama FROM ' . ($jual ? 'pelanggan' : 'pemasok') . ' WHERE id=?'); $q->execute([$t['kontak_id']]); $kn = $q->fetchColumn() ?: '-'; }
$it = $pdo->prepare('SELECT i.*, b.nama FROM transaksi_item i JOIN barang b ON b.id=i.barang_id WHERE i.transaksi_id=?');
$it->execute([$id]); $items = $it->fetchAll();
$judul = setting($jual ? 'nota_judul_jual' : 'nota_judul_beli', $jual ? 'FAKTUR PENJUALAN' : 'FAKTUR PEMBELIAN');
$lebar = setting('nota_lebar', '58') === '80' ? '80mm' : '58mm';
$kertas = setting('nota_kertas', 'A5') === 'A4' ? 'A4' : 'A5';
$sisa = round($t['total'] - $t['dibayar'], 2);
?><!doctype html><html lang="id"><head><meta charset="utf-8">
<title><?= e($t['nomor']) ?></title>
<style>
body{margin:0;font-family:<?= $besar ? '"Segoe UI",Arial,sans-serif' : '"Courier New",monospace' ?>;color:#000;font-size:<?= $besar ? '13px' : '11px' ?>}
.wrap{<?= $besar ? 'padding:8mm' : 'width:' . $lebar . ';padding:2mm' ?>}
h1{font-size:<?= $besar ? '20px' : '14px' ?>;margin:0}
.c{text-align:center}.r{text-align:right}.hr{border-top:1px dashed #000;margin:4px 0}
table{width:100%;border-collapse:collapse}
.big th,.big td{border:1px solid #999;padding:5px 7px}.big th{background:#eee}
.head{display:flex;justify-content:space-between;gap:16px;margin-bottom:10px}
.sign{display:flex;justify-content:space-around;margin-top:36px;text-align:center}
.tools{padding:8px;background:#eee;text-align:center}
@page{size:<?= $besar ? $kertas : $lebar . ' auto' ?>;margin:<?= $besar ? '8mm' : '2mm' ?>}
@media print{.tools{display:none}}
</style></head><body>
<div class="tools"><button onclick="window.print()">Cetak</button></div>
<div class="wrap">
<?php if (!$besar): ?>
  <div class="c"><h1><?= e(setting('nota_nama', APP_NAME)) ?></h1>
    <div><?= nl2br(e(setting('nota_alamat'))) ?></div><div><?= e(setting('nota_telp')) ?></div></div>
  <div class="hr"></div>
  <div><?= e($t['nomor']) ?><br><?= tgl($t['tanggal']) ?> <?= e(date('H:i', strtotime($t['created_at']))) ?>
    <?php if (setting('nota_tampil_kasir', '1') === '1'): ?><br>Kasir: <?= e($t['kasir']) ?><?php endif; ?>
    <br><?= $jual ? 'Pelanggan' : 'Pemasok' ?>: <?= e($kn) ?></div>
  <div class="hr"></div>
  <?php foreach ($items as $i): ?>
    <div><?= e($i['nama']) ?></div>
    <table><tr><td><?= qf($i['qty']) ?> x <?= number_format($i['harga'], 0, ',', '.') ?></td><td class="r"><?= number_format($i['subtotal'], 0, ',', '.') ?></td></tr></table>
  <?php endforeach; ?>
  <div class="hr"></div>
  <table>
    <?php if ($t['ppn'] > 0): ?>
    <tr><td>Subtotal</td><td class="r"><?= number_format($t['subtotal'], 0, ',', '.') ?></td></tr>
    <tr><td>PPN <?= qf($t['ppn_persen']) ?>%</td><td class="r"><?= number_format($t['ppn'], 0, ',', '.') ?></td></tr>
    <?php endif; ?>
    <tr><td>Total</td><td class="r"><b><?= number_format($t['total'], 0, ',', '.') ?></b></td></tr>
    <tr><td>Bayar</td><td class="r"><?= number_format($t['dibayar'], 0, ',', '.') ?></td></tr>
    <tr><td><?= $sisa > 0 ? 'Sisa' : 'Lunas' ?></td><td class="r"><?= $sisa > 0 ? number_format($sisa, 0, ',', '.') : '' ?></td></tr>
  </table>
  <div class="hr"></div>
  <div class="c"><?= nl2br(e(setting('nota_footer'))) ?></div>
<?php else: ?>
  <div class="head">
    <div><h1><?= e(setting('nota_nama', APP_NAME)) ?></h1><?= nl2br(e(setting('nota_alamat'))) ?><br><?= e(setting('nota_telp')) ?></div>
    <div class="r"><h1><?= e($judul) ?></h1>No: <?= e($t['nomor']) ?><br>Tanggal: <?= tgl($t['tanggal']) ?><br>
      <?= $jual ? 'Pelanggan' : 'Pemasok' ?>: <?= e($kn) ?>
      <?php if (setting('nota_tampil_kasir', '1') === '1'): ?><br>Dibuat oleh: <?= e($t['kasir']) ?><?php endif; ?></div>
  </div>
  <table class="big">
    <tr><th>No</th><th>Barang</th><th class="r">Jumlah</th><th class="r">Harga</th><th class="r">Subtotal</th></tr>
    <?php foreach ($items as $n => $i): ?>
      <tr><td><?= $n + 1 ?></td><td><?= e($i['nama']) ?></td><td class="r"><?= qf($i['qty']) ?></td><td class="r"><?= rp($i['harga']) ?></td><td class="r"><?= rp($i['subtotal']) ?></td></tr>
    <?php endforeach; ?>
    <?php if ($t['ppn'] > 0): ?>
    <tr><td colspan="4" class="r">Subtotal</td><td class="r"><?= rp($t['subtotal']) ?></td></tr>
    <tr><td colspan="4" class="r">PPN <?= qf($t['ppn_persen']) ?>%</td><td class="r"><?= rp($t['ppn']) ?></td></tr>
    <?php endif; ?>
    <tr><th colspan="4" class="r">Total</th><th class="r"><?= rp($t['total']) ?></th></tr>
    <tr><td colspan="4" class="r">Dibayar</td><td class="r"><?= rp($t['dibayar']) ?></td></tr>
    <tr><td colspan="4" class="r">Sisa</td><td class="r"><?= rp($sisa) ?></td></tr>
  </table>
  <?php if ($t['catatan']): ?><p>Catatan: <?= e($t['catatan']) ?></p><?php endif; ?>
  <?php if (setting('nota_catatan')): ?><p><?= nl2br(e(setting('nota_catatan'))) ?></p><?php endif; ?>
  <div class="sign"><div>Penerima<br><br><br>(__________)</div><div>Hormat kami<br><br><br>(__________)</div></div>
  <p class="c"><?= nl2br(e(setting('nota_footer'))) ?></p>
<?php endif; ?>
</div></body></html>
