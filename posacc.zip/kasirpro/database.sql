CREATE DATABASE IF NOT EXISTS pos_accurate CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE pos_accurate;

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL UNIQUE,
  nama VARCHAR(100) NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('manager','supervisor','kasir') NOT NULL DEFAULT 'kasir',
  aktif TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE kategori (id INT AUTO_INCREMENT PRIMARY KEY, nama VARCHAR(100) NOT NULL UNIQUE);
CREATE TABLE satuan   (id INT AUTO_INCREMENT PRIMARY KEY, nama VARCHAR(50) NOT NULL UNIQUE);
CREATE TABLE gudang (
  id INT AUTO_INCREMENT PRIMARY KEY, kode VARCHAR(20) NOT NULL UNIQUE,
  nama VARCHAR(100) NOT NULL, alamat TEXT NULL
);
CREATE TABLE pelanggan (
  id INT AUTO_INCREMENT PRIMARY KEY, kode VARCHAR(20) NOT NULL UNIQUE,
  nama VARCHAR(150) NOT NULL, telepon VARCHAR(30) NULL, email VARCHAR(100) NULL,
  alamat TEXT NULL, limit_piutang DECIMAL(15,2) NOT NULL DEFAULT 0
);
CREATE TABLE pemasok (
  id INT AUTO_INCREMENT PRIMARY KEY, kode VARCHAR(20) NOT NULL UNIQUE,
  nama VARCHAR(150) NOT NULL, telepon VARCHAR(30) NULL, email VARCHAR(100) NULL, alamat TEXT NULL
);
CREATE TABLE barang (
  id INT AUTO_INCREMENT PRIMARY KEY, kode VARCHAR(30) NOT NULL UNIQUE,
  nama VARCHAR(200) NOT NULL,
  kategori_id INT NULL, satuan_id INT NULL,
  harga_beli DECIMAL(15,2) NOT NULL DEFAULT 0,
  harga_jual DECIMAL(15,2) NOT NULL DEFAULT 0,
  stok_minimum DECIMAL(15,2) NOT NULL DEFAULT 0,
  FOREIGN KEY (kategori_id) REFERENCES kategori(id),
  FOREIGN KEY (satuan_id)   REFERENCES satuan(id)
);
CREATE TABLE akun (
  id INT AUTO_INCREMENT PRIMARY KEY, kode VARCHAR(20) NOT NULL UNIQUE,
  nama VARCHAR(150) NOT NULL,
  tipe ENUM('Aset','Kewajiban','Modal','Pendapatan','Beban') NOT NULL
);

INSERT INTO satuan (nama) VALUES ('Pcs'),('Box'),('Set'),('Kg'),('Liter');
INSERT INTO gudang (kode,nama) VALUES ('GD-01','Gudang Utama');
INSERT INTO akun (kode,nama,tipe) VALUES
 ('1-1000','Kas','Aset'),('1-1100','Bank','Aset'),('1-1200','Piutang Usaha','Aset'),
 ('1-1300','Persediaan Barang','Aset'),('2-1000','Hutang Usaha','Kewajiban'),
 ('3-1000','Modal Pemilik','Modal'),('4-1000','Penjualan','Pendapatan'),
 ('5-1000','Harga Pokok Penjualan','Beban'),('6-1000','Beban Operasional','Beban');
