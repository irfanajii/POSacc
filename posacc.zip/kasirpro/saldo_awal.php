<?php
require __DIR__ . '/config.php';
require __DIR__ . '/includes/layout.php';
require_role(['manager']);
$pdo = db();
$akun = $pdo->query("SELECT id,kode,nama,tipe FROM akun WHERE tipe IN ('Aset','Kewajiban','Modal') AND kode<>'3-1100' ORDER BY kode")->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $tgl = $_POST['tanggal'] ?? '';
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $tgl)) $tgl = date('Y-m-d');
    $lines = []; $sd = $sk = 0;
    foreach ($akun as $a) {
        $d = round(max(0, (float)($_POST['debit'][$a['id']] ?? 0)), 2); $k = round(max(0, (float)($_POST['kredit'][$a['id']] ?? 0)), 2);
        if ($d > 0 || $k > 0) { $lines[] = [$a['kode'], $d, $k]; $sd += $d; $sk += $k; }
    }
    $diff = round($sd - $sk, 2);
    if ($diff > 0) $lines[] = ['3-1100', 0, $diff]; elseif ($diff < 0) $lines[] = ['3-1100', -$diff, 0];
    try {
        $pdo->beginTransaction();
        $pdo->exec("DELETE FROM jurnal WHERE ref_tipe='saldo'");
        if ($lines) post_jurnal($tgl, 'Saldo awal', 'saldo', 0, $lines);
        $pdo->commit(); flash('Saldo awal tersimpan.');
    } catch (Throwable $ex) { if ($pdo->inTransaction()) $pdo->rollBack(); flash('Saldo awal gagal disimpan.', 'err'); }
    header('Location: saldo_awal.php'); exit;
}

$ex = $pdo->query("SELECT d.akun_id,d.debit,d.kredit,j.tanggal FROM jurnal_detail d JOIN jurnal j ON j.id=d.jurnal_id WHERE j.ref_tipe='saldo'")->fetchAll();
$cur = []; $tglAwal = date('Y-m-01');
foreach ($ex as $r) { $cur[$r['akun_id']] = $r; $tglAwal = $r['tanggal']; }
page_start('Saldo awal', 'saldo');
?>
<div class="panel">
  <p class="muted">Isi saldo akun pada hari pertama memakai aplikasi ini. Selisih debit dan kredit otomatis masuk ke akun Modal Saldo Awal.
    Untuk persediaan, isi stok awal di menu Stok barang (centang "Ini stok awal"), lalu kosongkan akun Persediaan di sini agar tidak terhitung dua kali.
    Menyimpan ulang akan menggantikan saldo awal yang lama.</p>
  <form method="post">
    <input type="hidden" name="csrf" value="<?= e(csrf()) ?>">
    <div class="grid"><label>Tanggal saldo awal<input type="date" name="tanggal" value="<?= e($tglAwal) ?>" required></label></div>
    <div class="scroll"><table>
      <thead><tr><th>Akun</th><th>Tipe</th><th>Debit</th><th>Kredit</th></tr></thead>
      <?php foreach ($akun as $a): ?><tr><td><?= e($a['kode'] . ' ' . $a['nama']) ?></td><td><?= e($a['tipe']) ?></td>
        <td><input type="number" name="debit[<?= $a['id'] ?>]" step="any" min="0" value="<?= e($cur[$a['id']]['debit'] ?? '') ?>"></td>
        <td><input type="number" name="kredit[<?= $a['id'] ?>]" step="any" min="0" value="<?= e($cur[$a['id']]['kredit'] ?? '') ?>"></td></tr><?php endforeach; ?>
    </table></div>
    <p><button class="btn">Simpan saldo awal</button></p>
  </form>
</div>
<?php page_end();
