<?php
const DB_HOST = 'localhost', DB_NAME = 'pos_accurate', DB_USER = 'root', DB_PASS = '';
const APP_NAME = 'KasirPro';

date_default_timezone_set('Asia/Jakarta');

session_start([
    'cookie_httponly' => true,
    'cookie_samesite' => 'Lax',
]);

function db(): PDO {
    static $pdo = null;
    if (!$pdo) {
        $pdo = new PDO(
            'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4', DB_USER, DB_PASS,
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]
        );
    }
    return $pdo;
}
function e($s): string { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function rp($n): string { return 'Rp ' . number_format((float)$n, 0, ',', '.'); }
function user(): ?array { return $_SESSION['user'] ?? null; }

function csrf(): string {
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(16));
    return $_SESSION['csrf'];
}
function csrf_check(): void {
    if (!hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '')) {
        http_response_code(419);
        exit('Sesi tidak valid. Muat ulang halaman lalu coba lagi.');
    }
}
function require_login(): void {
    if (!user()) { header('Location: login.php'); exit; }
}
function require_role(array $roles): void {
    require_login();
    if (!in_array(user()['role'], $roles, true)) {
        http_response_code(403);
        exit('Anda tidak punya akses ke halaman ini.');
    }
}
function flash(?string $msg = null, string $type = 'ok') {
    if ($msg !== null) { $_SESSION['flash'] = [$msg, $type]; return null; }
    $f = $_SESSION['flash'] ?? null;
    unset($_SESSION['flash']);
    return $f;
}
