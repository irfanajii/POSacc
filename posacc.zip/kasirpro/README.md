# KasirPro - Tahap 1

Login, hak akses (Manager / Supervisor / Admin-Kasir), dan data master.

## Pasang
1. Pastikan PHP 8.0+ dan MySQL/MariaDB aktif (XAMPP/Laragon cukup).
2. Instalasi baru: impor `database_lengkap.sql` saja (hapus database `pos_accurate` lebih dulu jika sudah ada). Upgrade dari versi lama: impor `database_tahap2.sql` lalu `database_tahap3.sql`, sesuai urutan.
3. Sesuaikan DB_HOST, DB_USER, DB_PASS di `config.php`.
4. Salin folder ke `htdocs` dan buka `http://localhost/kasirpro/`.
5. Saat pertama dibuka, buat akun Manager pertama.

## Hak akses
- Manager: semua fitur, termasuk hapus data dan kelola pengguna
- Supervisor: tambah dan ubah data master
- Admin/Kasir: lihat data master, tambah dan ubah pelanggan

## Menambah data master baru
Tambah satu entri di `includes/entities.php` dan tabelnya di database. Halaman daftar, form, dan pencarian dibuat otomatis.

## Fitur tahap 2 dan 3
- Penjualan dan pembelian (tunai atau kredit), stok otomatis, jurnal otomatis
- Pelunasan piutang dan hutang, pembatalan transaksi (Manager)
- Nota kecil (58/80 mm) dan nota besar (A5/A4), menu Desain nota untuk mengubah tampilannya
- Stok barang: filter gudang, pemasok, pelanggan; kartu stok; penyesuaian stok; cetak
- Jurnal umum dan laporan: penjualan, pembelian (terpisah), laba rugi, neraca, piutang, hutang; semuanya bisa dicetak per bulan

## Fitur tahap 4
- PPN per transaksi (tarif di menu Pajak), laporan PPN keluaran/masukan
- Retur penjualan dan pembelian (memotong piutang/hutang, sisanya tunai), stok dan jurnal menyesuaikan
- Harga bertingkat: eceran, grosir, partai; tiap pelanggan punya level harga
- Harga beli rata-rata bergerak, dipakai untuk HPP
- Jurnal manual, saldo awal akun, dan jurnal otomatis untuk penyesuaian stok

## Batasan
Retur tidak bisa dibatalkan (koreksi dengan jurnal manual). Harga di transaksi belum termasuk PPN.
Belum ada faktur pajak/e-Faktur, mata uang asing, atau penyusutan aset.
