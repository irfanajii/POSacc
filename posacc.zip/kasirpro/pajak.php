<?php
require __DIR__ . '/config.php';
require __DIR__ . '/includes/layout.php';
require_role(['manager']);
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    set_setting('ppn_aktif', isset($_POST['ppn_aktif']) ? '1' : '0');
    set_setting('ppn_persen', (string)max(0, min(100, (float)($_POST['ppn_persen'] ?? 0))));
    flash('Pengaturan pajak tersimpan.');
    header('Location: pajak.php'); exit;
}
page_start('Pajak (PPN)', 'pajak');
?>
<div class="panel">
  <form method="post" class="grid">
    <input type="hidden" name="csrf" value="<?= e(csrf()) ?>">
    <label><span><input type="checkbox" name="ppn_aktif" style="width:auto" <?= setting('ppn_aktif', '0') === '1' ? 'checked' : '' ?>> Kenakan PPN secara bawaan pada transaksi baru</span></label>
    <label>Tarif PPN (%)<input type="number" name="ppn_persen" step="any" min="0" max="100" value="<?= e(setting('ppn_persen', '11')) ?>"></label>
    <div class="actions"><button class="btn">Simpan</button></div>
  </form>
  <p class="muted">Harga di transaksi dianggap belum termasuk PPN. Pada setiap transaksi, PPN tetap bisa dicentang atau dimatikan.
    Pastikan tarif dan cara hitungnya sesuai dengan ketentuan pajak usahamu; tanyakan ke akuntan atau konsultan pajak bila ragu.</p>
</div>
<?php page_end();
