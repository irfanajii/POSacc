<?php
require __DIR__ . '/config.php';
require __DIR__ . '/includes/layout.php';
require_role(['manager', 'supervisor']);
$pdo = db();

/* ---------- Buat retur dari satu transaksi ---------- */
if (isset($_GET['trx'])) {
    $trx = (int)$_GET['trx'];
    $s = $pdo->prepare("SELECT * FROM transaksi WHERE id=? AND status='aktif'"); $s->execute([$trx]); $t = $s->fetch();
    if (!$t) { http_response_code(404); exit('Transaksi tidak ditemukan atau sudah dibatalkan.'); }
    $jual = $t['tipe'] === 'jual';
    $it = $pdo->prepare('SELECT i.barang_id, b.kode, b.nama, b.harga_beli, SUM(i.qty) q, SUM(i.subtotal)/SUM(i.qty) harga
        FROM transaksi_item i JOIN barang b ON b.id=i.barang_id WHERE i.transaksi_id=? GROUP BY i.barang_id, b.kode, b.nama, b.harga_beli');
    $it->execute([$trx]); $items = $it->fetchAll();
    $rt = $pdo->prepare('SELECT ri.barang_id, SUM(ri.qty) FROM retur_item ri JOIN retur r ON r.id=ri.retur_id WHERE r.transaksi_id=? GROUP BY ri.barang_id');
    $rt->execute([$trx]); $done = $rt->fetchAll(PDO::FETCH_KEY_PAIR);
    $err = '';

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        csrf_check();
        $tgl = $_POST['tanggal'] ?? '';
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $tgl)) $tgl = date('Y-m-d');
        $rows = []; $subtotal = 0; $hpp = 0;
        foreach ($items as $i) {
            $q = (float)($_POST['qty'][$i['barang_id']] ?? 0);
            if ($q <= 0) continue;
            $rem = $i['q'] - ($done[$i['barang_id']] ?? 0);
            if ($q > $rem + 0.0001) { $err = 'Jumlah retur ' . $i['nama'] . ' melebihi sisa yang bisa diretur (' . qf($rem) . ').'; break; }
            if (!$jual && stok($i['barang_id'], (int)$t['gudang_id']) < $q) { $err = 'Stok ' . $i['nama'] . ' tidak cukup untuk diretur ke pemasok.'; break; }
            $h = round($i['harga'], 2); $sub = round($q * $h, 2);
            $rows[] = [$i['barang_id'], $q, $h, $sub]; $subtotal += $sub; $hpp += $q * $i['harga_beli'];
        }
        if (!$err && !$rows) $err = 'Isi jumlah retur untuk minimal satu barang.';
        if (!$err) {
            $subtotal = round($subtotal, 2); $ppn = round($subtotal * $t['ppn_persen'] / 100, 2); $total = round($subtotal + $ppn, 2);
            $sisa = max(round($t['total'] - $t['dibayar'], 2), 0);
            $potong = min($total, $sisa); $refund = round($total - $potong, 2); $hpp = round($hpp, 2);
            try {
                $pdo->beginTransaction();
                $nomor = nomor($jual ? 'RJ' : 'RB', $tgl, 'retur');
                $pdo->prepare('INSERT INTO retur (tipe,nomor,tanggal,transaksi_id,gudang_id,subtotal,ppn,total,potong,refund,catatan,user_id) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)')
                    ->execute([$t['tipe'], $nomor, $tgl, $trx, $t['gudang_id'], $subtotal, $ppn, $total, $potong, $refund, trim($_POST['catatan'] ?? '') ?: null, user()['id']]);
                $rid = (int)$pdo->lastInsertId();
                $ins = $pdo->prepare('INSERT INTO retur_item (retur_id,barang_id,qty,harga,subtotal) VALUES (?,?,?,?,?)');
                $log = $pdo->prepare('INSERT INTO stok_log (barang_id,gudang_id,qty,ref_tipe,ref_id,tanggal,ket) VALUES (?,?,?,?,?,?,?)');
                foreach ($rows as [$bid, $q, $h, $sub]) {
                    $ins->execute([$rid, $bid, $q, $h, $sub]);
                    $log->execute([$bid, $t['gudang_id'], $jual ? $q : -$q, $jual ? 'rjual' : 'rbeli', $rid, $tgl, $nomor]);
                }
                if ($potong > 0) {
                    $pdo->prepare('UPDATE transaksi SET dibayar=dibayar+? WHERE id=?')->execute([$potong, $trx]);
                    $pdo->prepare('INSERT INTO pembayaran (transaksi_id,tanggal,jumlah,ket) VALUES (?,?,?,?)')
                        ->execute([$trx, $tgl, $potong, "Diperhitungkan dari retur $nomor"]);
                }
                if ($jual) post_jurnal($tgl, "Retur penjualan $nomor", 'rjual', $rid, [
                    ['4-1000', $subtotal, 0], ['2-1100', $ppn, 0], ['1-1200', 0, $potong], ['1-1000', 0, $refund],
                    ['1-1300', $hpp, 0], ['5-1000', 0, $hpp]]);
                else post_jurnal($tgl, "Retur pembelian $nomor", 'rbeli', $rid, [
                    ['2-1000', $potong, 0], ['1-1000', $refund, 0], ['1-1300', 0, $subtotal], ['1-1400', 0, $ppn]]);
                $pdo->commit();
                flash("Retur $nomor tersimpan.");
                header('Location: retur.php?id=' . $rid); exit;
            } catch (Throwable $ex) {
                if ($pdo->inTransaction()) $pdo->rollBack();
                $err = 'Retur gagal disimpan. Coba lagi.';
            }
        }
    }

    page_start('Retur ' . ($jual ? 'penjualan ' : 'pembelian ') . $t['nomor'], $jual ? 'rjual' : 'rbeli');
    ?>
    <div class="panel">
      <?php if ($err): ?><div class="flash err"><?= e($err) ?></div><?php endif; ?>
      <p class="muted">Harga retur mengikuti harga di transaksi asal<?= $t['ppn'] > 0 ? ', ditambah PPN ' . qf($t['ppn_persen']) . '%' : '' ?>.
        Jika transaksi asal masih ada sisa <?= $jual ? 'piutang' : 'hutang' ?>, retur memotong sisa itu lebih dulu; kelebihannya dikembalikan tunai.</p>
      <form method="post">
        <input type="hidden" name="csrf" value="<?= e(csrf()) ?>">
        <div class="grid"><label>Tanggal retur<input type="date" name="tanggal" value="<?= e($_POST['tanggal'] ?? date('Y-m-d')) ?>" required></label>
          <label>Catatan<input name="catatan" maxlength="255" value="<?= e($_POST['catatan'] ?? '') ?>"></label></div>
        <div class="scroll"><table>
          <thead><tr><th>Barang</th><th class="num"><?= $jual ? 'Terjual' : 'Dibeli' ?></th><th class="num">Sudah diretur</th><th class="num">Harga</th><th>Jumlah retur</th></tr></thead>
          <?php foreach ($items as $i): $rem = $i['q'] - ($done[$i['barang_id']] ?? 0); ?>
            <tr><td><?= e($i['kode'] . ' - ' . $i['nama']) ?></td><td class="num"><?= qf($i['q']) ?></td>
              <td class="num"><?= qf($done[$i['barang_id']] ?? 0) ?></td><td class="num"><?= rp($i['harga']) ?></td>
              <td><input type="number" name="qty[<?= $i['barang_id'] ?>]" step="any" min="0" max="<?= $rem ?>" value="<?= e($_POST['qty'][$i['barang_id']] ?? '') ?>" <?= $rem <= 0 ? 'disabled' : '' ?>></td></tr>
          <?php endforeach; ?>
        </table></div>
        <p class="actions"><button class="btn">Simpan retur</button><a class="btn ghost" href="detail.php?id=<?= $trx ?>">Batal</a></p>
      </form>
    </div>
    <?php page_end(); exit;
}

/* ---------- Lihat satu retur ---------- */
if (isset($_GET['id'])) {
    $s = $pdo->prepare('SELECT r.*, t.nomor tnomor, u.nama kasir FROM retur r JOIN transaksi t ON t.id=r.transaksi_id JOIN users u ON u.id=r.user_id WHERE r.id=?');
    $s->execute([(int)$_GET['id']]); $r = $s->fetch();
    if (!$r) { http_response_code(404); exit('Retur tidak ditemukan.'); }
    $it = $pdo->prepare('SELECT i.*, b.kode, b.nama FROM retur_item i JOIN barang b ON b.id=i.barang_id WHERE i.retur_id=?');
    $it->execute([$r['id']]);
    page_start('Retur ' . $r['nomor'], $r['tipe'] === 'jual' ? 'rjual' : 'rbeli'); ?>
    <div class="panel"><table>
      <tr><td>Tanggal</td><td><?= tgl($r['tanggal']) ?></td><td>Transaksi asal</td><td><a href="detail.php?id=<?= $r['transaksi_id'] ?>"><?= e($r['tnomor']) ?></a></td></tr>
      <tr><td>Dibuat oleh</td><td><?= e($r['kasir']) ?></td><td>Catatan</td><td><?= e($r['catatan'] ?? '-') ?></td></tr>
    </table></div>
    <div class="panel"><div class="scroll"><table>
      <thead><tr><th>Barang</th><th class="num">Jumlah</th><th class="num">Harga</th><th class="num">Subtotal</th></tr></thead>
      <?php foreach ($it->fetchAll() as $i): ?><tr><td><?= e($i['kode'] . ' - ' . $i['nama']) ?></td><td class="num"><?= qf($i['qty']) ?></td><td class="num"><?= rp($i['harga']) ?></td><td class="num"><?= rp($i['subtotal']) ?></td></tr><?php endforeach; ?>
      <tr><td colspan="3" class="num">Subtotal</td><td class="num"><?= rp($r['subtotal']) ?></td></tr>
      <tr><td colspan="3" class="num">PPN</td><td class="num"><?= rp($r['ppn']) ?></td></tr>
      <tr><th colspan="3" class="num">Total retur</th><th class="num"><?= rp($r['total']) ?></th></tr>
      <tr><td colspan="3" class="num">Memotong <?= $r['tipe'] === 'jual' ? 'piutang' : 'hutang' ?></td><td class="num"><?= rp($r['potong']) ?></td></tr>
      <tr><td colspan="3" class="num"><?= $r['tipe'] === 'jual' ? 'Dikembalikan tunai ke pelanggan' : 'Diterima tunai dari pemasok' ?></td><td class="num"><?= rp($r['refund']) ?></td></tr>
    </table></div><p><button class="btn no-print" onclick="window.print()">Cetak</button></p></div>
    <?php page_end(); exit;
}

/* ---------- Daftar retur ---------- */
$t = ($_GET['t'] ?? 'jual') === 'beli' ? 'beli' : 'jual'; $bulan = bulan_param();
$s = $pdo->prepare("SELECT r.*, x.nomor tnomor FROM retur r JOIN transaksi x ON x.id=r.transaksi_id
    WHERE r.tipe=? AND DATE_FORMAT(r.tanggal,'%Y-%m')=? ORDER BY r.tanggal DESC, r.id DESC");
$s->execute([$t, $bulan]); $list = $s->fetchAll();
page_start('Retur ' . ($t === 'jual' ? 'penjualan' : 'pembelian'), $t === 'jual' ? 'rjual' : 'rbeli'); ?>
<div class="panel">
  <form method="get" class="search"><input type="hidden" name="t" value="<?= $t ?>">
    <input type="month" name="bulan" value="<?= e($bulan) ?>"><button class="btn ghost">Tampilkan</button></form>
  <p class="muted">Retur dibuat dari halaman detail transaksi, lewat tombol Buat retur.</p>
  <div class="scroll"><table>
    <thead><tr><th>Nomor</th><th>Tanggal</th><th>Transaksi asal</th><th class="num">Total</th></tr></thead>
    <?php foreach ($list as $r): ?><tr><td><a href="retur.php?id=<?= $r['id'] ?>"><?= e($r['nomor']) ?></a></td><td><?= tgl($r['tanggal']) ?></td>
      <td><a href="detail.php?id=<?= $r['transaksi_id'] ?>"><?= e($r['tnomor']) ?></a></td><td class="num"><?= rp($r['total']) ?></td></tr><?php endforeach; ?>
    <?php if (!$list): ?><tr><td colspan="4" class="muted">Belum ada retur di bulan ini.</td></tr><?php endif; ?>
  </table></div>
</div>
<?php page_end();
