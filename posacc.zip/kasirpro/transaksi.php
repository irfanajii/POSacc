<?php
require __DIR__ . '/config.php';
require __DIR__ . '/includes/layout.php';
$t = $_GET['t'] ?? '';
if (!in_array($t, ['jual', 'beli'], true)) { http_response_code(404); exit('Halaman tidak ditemukan.'); }
$jual = $t === 'jual';
require_role($jual ? ['manager', 'supervisor', 'kasir'] : ['manager', 'supervisor']);
$pdo = db(); $judul = $jual ? 'Penjualan' : 'Pembelian'; $kt = $jual ? 'pelanggan' : 'pemasok';
$kontak = $pdo->query("SELECT id,nama FROM `$kt` ORDER BY nama")->fetchAll(PDO::FETCH_KEY_PAIR);
$gudang = $pdo->query('SELECT id,nama FROM gudang ORDER BY id')->fetchAll(PDO::FETCH_KEY_PAIR);
$barang = $pdo->query('SELECT id,kode,nama,harga_beli,harga_jual,harga_jual2,harga_jual3 FROM barang ORDER BY nama')->fetchAll();
$bmap = array_column($barang, null, 'id');
$lv = $jual ? $pdo->query('SELECT id,level_harga FROM pelanggan')->fetchAll(PDO::FETCH_KEY_PAIR) : [];
$ppnPct = (float)setting('ppn_persen', '11'); $ppnOn = setting('ppn_aktif', '0') === '1';
$err = ''; $form = isset($_GET['baru']); $init = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check(); $form = true;
    $tgl = $_POST['tanggal'] ?? '';
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $tgl)) $tgl = date('Y-m-d');
    $kid = (int)($_POST['kontak_id'] ?? 0); if (!isset($kontak[$kid])) $kid = null;
    $gid = (int)($_POST['gudang_id'] ?? 0);
    $cat = trim($_POST['catatan'] ?? '');
    $rows = []; $need = []; $total = 0;
    foreach (($_POST['barang_id'] ?? []) as $i => $bid) {
        $bid = (int)$bid; $q = (float)($_POST['qty'][$i] ?? 0); $h = max(0, (float)($_POST['harga'][$i] ?? 0));
        if ($bid && $q > 0 && isset($bmap[$bid])) { $rows[] = [$bid, $q, $h]; $need[$bid] = ($need[$bid] ?? 0) + $q; $total += $q * $h; }
    }
    $init = $rows;
    $subtotal = round($total, 2);
    $pp = isset($_POST['kena_ppn']) ? $ppnPct : 0;
    $ppn = round($subtotal * $pp / 100, 2);
    $total = round($subtotal + $ppn, 2);
    $bayar = round(min(max((float)($_POST['dibayar'] ?? 0), 0), $total), 2);
    $sisa = round($total - $bayar, 2);
    if (!$rows) $err = 'Tambahkan minimal satu barang dengan jumlah lebih dari 0.';
    elseif (!isset($gudang[$gid])) $err = 'Pilih gudang.';
    elseif ($sisa > 0 && !$kid) $err = 'Pilih ' . $kt . ' untuk transaksi yang belum lunas.';
    elseif ($jual) foreach ($need as $bid => $q)
        if (stok($bid, $gid) < $q) { $err = 'Stok ' . $bmap[$bid]['nama'] . ' tidak cukup (tersedia ' . qf(stok($bid, $gid)) . ').'; break; }

    if (!$err) {
        try {
            $pdo->beginTransaction();
            $nomor = nomor($jual ? 'JL' : 'BL', $tgl);
            $pdo->prepare('INSERT INTO transaksi (tipe,nomor,tanggal,kontak_id,gudang_id,subtotal,ppn_persen,ppn,total,dibayar,catatan,user_id) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)')
                ->execute([$t, $nomor, $tgl, $kid, $gid, $subtotal, $pp, $ppn, $total, $bayar, $cat ?: null, user()['id']]);
            $tid = (int)$pdo->lastInsertId(); $hpp = 0;
            $cost = array_map(fn($b) => (float)$b['harga_beli'], $bmap);
            $ins = $pdo->prepare('INSERT INTO transaksi_item (transaksi_id,barang_id,qty,harga,subtotal) VALUES (?,?,?,?,?)');
            $log = $pdo->prepare('INSERT INTO stok_log (barang_id,gudang_id,qty,ref_tipe,ref_id,tanggal,ket) VALUES (?,?,?,?,?,?,?)');
            foreach ($rows as [$bid, $q, $h]) {
                $ins->execute([$tid, $bid, $q, $h, round($q * $h, 2)]);
                $log->execute([$bid, $gid, $jual ? -$q : $q, $t, $tid, $tgl, $nomor]);
                if ($jual) $hpp += $q * $bmap[$bid]['harga_beli'];
                else { // harga beli rata-rata bergerak
                    $sa = stok($bid); $prev = max($sa - $q, 0);
                    $cost[$bid] = $sa > 0 ? ($prev * $cost[$bid] + $q * $h) / ($prev + $q) : $h;
                    $pdo->prepare('UPDATE barang SET harga_beli=? WHERE id=?')->execute([round($cost[$bid], 2), $bid]);
                }
            }
            $hpp = round($hpp, 2);
            if ($jual) post_jurnal($tgl, "Penjualan $nomor", 'jual', $tid, [
                ['1-1000', $bayar, 0], ['1-1200', $sisa, 0], ['4-1000', 0, $subtotal], ['2-1100', 0, $ppn], ['5-1000', $hpp, 0], ['1-1300', 0, $hpp]]);
            else post_jurnal($tgl, "Pembelian $nomor", 'beli', $tid, [
                ['1-1300', $subtotal, 0], ['1-1400', $ppn, 0], ['1-1000', 0, $bayar], ['2-1000', 0, $sisa]]);
            $pdo->commit();
            flash("Transaksi $nomor tersimpan.");
            header('Location: detail.php?id=' . $tid); exit;
        } catch (Throwable $ex) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            $err = 'Transaksi gagal disimpan. Coba lagi.';
        }
    }
}

page_start($judul, $t);
if ($form): ?>
<div class="panel">
  <h2><?= $judul ?> baru</h2>
  <?php if ($err): ?><div class="flash err"><?= e($err) ?></div><?php endif; ?>
  <form method="post" id="f">
    <input type="hidden" name="csrf" value="<?= e(csrf()) ?>">
    <div class="grid">
      <label>Tanggal<input type="date" name="tanggal" value="<?= e($_POST['tanggal'] ?? date('Y-m-d')) ?>" required></label>
      <label><?= $jual ? 'Pelanggan' : 'Pemasok' ?>
        <select name="kontak_id"><option value=""><?= $jual ? 'Umum (tanpa nama)' : '-' ?></option>
        <?php foreach ($kontak as $id => $nm): ?><option value="<?= $id ?>" <?= ($_POST['kontak_id'] ?? '') == $id ? 'selected' : '' ?>><?= e($nm) ?></option><?php endforeach; ?></select></label>
      <label>Gudang<select name="gudang_id"><?php foreach ($gudang as $id => $nm): ?>
        <option value="<?= $id ?>" <?= ($_POST['gudang_id'] ?? '') == $id ? 'selected' : '' ?>><?= e($nm) ?></option><?php endforeach; ?></select></label>
      <label>Catatan<input name="catatan" maxlength="255" value="<?= e($_POST['catatan'] ?? '') ?>"></label>
    </div>
    <div class="scroll"><table class="items">
      <thead><tr><th>Barang</th><th>Jumlah</th><th>Harga</th><th>Subtotal</th><th></th></tr></thead>
      <tbody id="rows"></tbody>
    </table></div>
    <p><button type="button" class="btn ghost" id="add">Tambah baris</button></p>
    <div class="grid">
      <label><span><input type="checkbox" name="kena_ppn" id="ppn" style="width:auto" <?= ($_SERVER['REQUEST_METHOD'] === 'POST' ? isset($_POST['kena_ppn']) : $ppnOn) ? 'checked' : '' ?>> Kena PPN <?= qf($ppnPct) ?>% (harga belum termasuk PPN)</span></label>
      <label>Subtotal<input id="subtotal" readonly></label>
      <label>PPN<input id="ppnamt" readonly></label>
      <label>Total<input id="total" readonly></label>
      <label>Dibayar<input type="number" name="dibayar" id="bayar" step="any" min="0" value="<?= e($_POST['dibayar'] ?? '') ?>"></label>
      <label>Sisa / kembali<input id="sisa" readonly></label>
    </div>
    <p class="actions"><button class="btn">Simpan transaksi</button><a class="btn ghost" href="transaksi.php?t=<?= $t ?>">Batal</a></p>
  </form>
</div>
<script>
const B = <?= json_encode($barang, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
const JUAL = <?= $jual ? 'true' : 'false' ?>;
const INIT = <?= json_encode($init) ?>;
const LV = <?= json_encode($lv) ?>, PPN = <?= json_encode($ppnPct) ?>;
function price(b) {
  if (!b) return 0;
  if (!JUAL) return b.harga_beli;
  const l = LV[document.querySelector('[name=kontak_id]').value] || 1;
  const v = l == 3 ? +b.harga_jual3 : l == 2 ? +b.harga_jual2 : 0;
  return v > 0 ? v : b.harga_jual;
}
const rows = document.getElementById('rows'), bayar = document.getElementById('bayar');
let bayarManual = bayar.value !== '';
const fmt = n => 'Rp ' + Math.round(n).toLocaleString('id-ID');
function addRow(v) {
  const tr = document.createElement('tr');
  tr.innerHTML = '<td><select name="barang_id[]"></select></td><td><input type="number" name="qty[]" step="any" min="0" value="1"></td>' +
    '<td><input type="number" name="harga[]" step="any" min="0" value="0"></td><td class="num sub">0</td><td><button type="button" class="link danger">Hapus</button></td>';
  const sel = tr.querySelector('select');
  sel.add(new Option('Pilih barang', ''));
  B.forEach(b => sel.add(new Option(b.kode + ' - ' + b.nama, b.id)));
  const [qty, harga] = tr.querySelectorAll('input');
  sel.onchange = () => { const b = B.find(x => x.id == sel.value); harga.value = price(b); calc(); };
  tr.querySelector('button').onclick = () => { tr.remove(); calc(); };
  tr.oninput = calc;
  if (v) { sel.value = v[0]; qty.value = v[1]; harga.value = v[2]; }
  rows.appendChild(tr);
}
function calc() {
  let t = 0;
  rows.querySelectorAll('tr').forEach(tr => {
    const [q, h] = tr.querySelectorAll('input'); const s = (+q.value || 0) * (+h.value || 0);
    tr.querySelector('.sub').textContent = fmt(s); t += s;
  });
  const pp = document.getElementById('ppn').checked ? PPN : 0, px = Math.round(t * pp) / 100, g = t + px;
  if (!bayarManual) bayar.value = JUAL ? Math.round(g) : '';
  document.getElementById('subtotal').value = fmt(t);
  document.getElementById('ppnamt').value = fmt(px);
  document.getElementById('total').value = fmt(g);
  const d = (+bayar.value || 0) - g;
  document.getElementById('sisa').value = d >= 0 ? 'Kembali ' + fmt(d) : 'Sisa ' + fmt(-d);
}
bayar.oninput = () => { bayarManual = true; calc(); };
document.getElementById('ppn').onchange = calc;
if (JUAL) document.querySelector('[name=kontak_id]').onchange = () => {
  rows.querySelectorAll('tr').forEach(tr => {
    const b = B.find(x => x.id == tr.querySelector('select').value);
    if (b) tr.querySelectorAll('input')[1].value = price(b);
  });
  calc();
};
document.getElementById('add').onclick = () => addRow();
(INIT.length ? INIT : [null]).forEach(addRow); calc();
</script>
<?php endif; ?>

<?php
$bulan = bulan_param();
$st = $pdo->prepare("SELECT t.*, k.nama kontak FROM transaksi t LEFT JOIN `$kt` k ON k.id=t.kontak_id
  WHERE t.tipe=? AND DATE_FORMAT(t.tanggal,'%Y-%m')=? ORDER BY t.tanggal DESC, t.id DESC");
$st->execute([$t, $bulan]);
$list = $st->fetchAll();
?>
<div class="panel">
  <form method="get" class="search">
    <input type="hidden" name="t" value="<?= $t ?>">
    <input type="month" name="bulan" value="<?= e($bulan) ?>">
    <button class="btn ghost">Tampilkan</button>
    <a class="btn" href="transaksi.php?t=<?= $t ?>&baru=1">Baru</a>
  </form>
  <div class="scroll"><table>
    <thead><tr><th>Nomor</th><th>Tanggal</th><th><?= $jual ? 'Pelanggan' : 'Pemasok' ?></th><th class="num">Total</th><th class="num">Dibayar</th><th>Status</th></tr></thead>
    <?php foreach ($list as $r): ?>
      <tr>
        <td><a href="detail.php?id=<?= $r['id'] ?>"><?= e($r['nomor']) ?></a></td>
        <td><?= tgl($r['tanggal']) ?></td><td><?= e($r['kontak'] ?? 'Umum') ?></td>
        <td class="num"><?= rp($r['total']) ?></td><td class="num"><?= rp($r['dibayar']) ?></td>
        <td><?= $r['status'] === 'batal' ? 'Batal' : ($r['total'] - $r['dibayar'] > 0.005 ? 'Belum lunas' : 'Lunas') ?></td>
      </tr>
    <?php endforeach; ?>
    <?php if (!$list): ?><tr><td colspan="6" class="muted">Belum ada transaksi di bulan ini.</td></tr><?php endif; ?>
  </table></div>
</div>
<?php page_end();
